import * as React from 'react';
import { View,Button } from 'react-native';
import * as SQLite from 'expo-sqlite';
import Mybutton from './components/Mybutton';
import Mytext from './components/Mytext';

import { openDatabase } from 'react-native-sqlite-storage';

const db = SQLite.openDatabase('AprendeIngles.db');

export default class HomeScreen extends React.Component {
  constructor(props) {
    super(props);
    db.transaction(function(txn) {
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='USUARIOS'",
        [],
        function(tx, res) {
          console.log('item:', res.rows.length);
          if (res.rows.length == 0) {
            txn.executeSql('DROP TABLE IF EXISTS USUARIOS', []);
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS USUARIOS(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre VARCHAR(20) NOT NULL, correo VARCHAR(50) NOT NULL, contrasena VARCHAR(50) NOT NULL)',
              []
            );
          }
        }
      );
    });
  }
  render() {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: 'white',
          flexDirection: 'column',
        }}>
        <Mytext text="Prueba con SQLite" />
        <Mybutton
          title="Register"
          customClick={() => this.props.navigation.navigate('Register')}
        />
        <Mybutton
          title="View All"
          customClick={() => this.props.navigation.navigate('ViewAll')}
        />

         <Mybutton
          title="Login"
          customClick={() => this.props.navigation.navigate('Login')}
        />
      </View>
    );
  }
}