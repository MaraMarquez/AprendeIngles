import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import MaterialFixedLabelTextbox7 from "../components/MaterialFixedLabelTextbox7";

function P5(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <View style={styles.selectVowelsStack}>
        <Text style={styles.selectVowels}></Text>
        <Text style={styles.writeYourName}>COMPLETE THE ALPHABET</Text>
      </View>
      <View style={styles.iconRow}>
        <MaterialCommunityIconsIcon
          name="alpha-a-box"
          style={styles.icon}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-b-box"
          style={styles.icon2}
        ></MaterialCommunityIconsIcon>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox1}
        ></MaterialFixedLabelTextbox7>
        <View style={styles.icon4Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-d-box"
            style={styles.icon4}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-e-box"
            style={styles.icon5}
          ></MaterialCommunityIconsIcon>
        </View>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox3}
        ></MaterialFixedLabelTextbox7>
      </View>
      <View style={styles.materialFixedLabelTextbox2Row}>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox2}
        ></MaterialFixedLabelTextbox7>
        <MaterialCommunityIconsIcon
          name="alpha-h-box"
          style={styles.icon8}
        ></MaterialCommunityIconsIcon>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox4}
        ></MaterialFixedLabelTextbox7>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox5}
        ></MaterialFixedLabelTextbox7>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox6}
        ></MaterialFixedLabelTextbox7>
      </View>
      <View style={styles.icon12Row}>
        <MaterialCommunityIconsIcon
          name="alpha-l-box"
          style={styles.icon12}
        ></MaterialCommunityIconsIcon>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox7}
        ></MaterialFixedLabelTextbox7>
        <MaterialCommunityIconsIcon
          name="alpha-n-box"
          style={styles.icon14}
        ></MaterialCommunityIconsIcon>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox8}
        ></MaterialFixedLabelTextbox7>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox9}
        ></MaterialFixedLabelTextbox7>
      </View>
      <View style={styles.icon17StackRow}>
        <View style={styles.icon17Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-q-box"
            style={styles.icon17}
          ></MaterialCommunityIconsIcon>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox13}
          ></MaterialFixedLabelTextbox7>
        </View>
        <MaterialCommunityIconsIcon
          name="alpha-s-box"
          style={styles.icon19}
        ></MaterialCommunityIconsIcon>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox10}
        ></MaterialFixedLabelTextbox7>
        <MaterialCommunityIconsIcon
          name="alpha-u-box"
          style={styles.icon21}
        ></MaterialCommunityIconsIcon>
      </View>
      <View style={styles.icon22StackStack}>
        <View style={styles.icon22Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-v-box"
            style={styles.icon22}
          ></MaterialCommunityIconsIcon>
          <Image
            source={require("../assets/images/baa3684e347bab2b3652360ebc4e05a2.png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <View style={styles.icon23Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-w-box"
            style={styles.icon23}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-w-box"
            style={styles.icon27}
          ></MaterialCommunityIconsIcon>
        </View>
        <View style={styles.icon26Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-z-box"
            style={styles.icon26}
          ></MaterialCommunityIconsIcon>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox15}
          ></MaterialFixedLabelTextbox7>
        </View>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox14}
        ></MaterialFixedLabelTextbox7>
      </View>
      <Text style={styles.completaElAlfabeto}>COMPLETA EL ALFABETO</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 52
  },
  selectVowels: {
    top: 25,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  writeYourName: {
    top: 0,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  selectVowelsStack: {
    width: 375,
    height: 90,
    marginTop: 21
  },
  icon: {
    color: "rgba(225,229,78,1)",
    fontSize: 58
  },
  icon2: {
    color: "rgba(250,87,87,1)",
    fontSize: 58
  },
  materialFixedLabelTextbox1: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 1,
    marginTop: 7
  },
  icon4: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(242,168,94,1)",
    fontSize: 58
  },
  icon5: {
    top: 0,
    left: 48,
    position: "absolute",
    color: "rgba(150,205,109,1)",
    fontSize: 58
  },
  icon4Stack: {
    width: 106,
    height: 58,
    marginLeft: 1
  },
  materialFixedLabelTextbox3: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginTop: 7
  },
  iconRow: {
    height: 58,
    flexDirection: "row",
    marginTop: 54,
    marginLeft: 41,
    marginRight: 14
  },
  materialFixedLabelTextbox2: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginTop: 7
  },
  icon8: {
    color: "rgba(74,68,131,1)",
    fontSize: 58
  },
  materialFixedLabelTextbox4: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 6
  },
  materialFixedLabelTextbox5: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 15
  },
  materialFixedLabelTextbox6: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 15
  },
  materialFixedLabelTextbox2Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 32,
    marginLeft: 30,
    marginRight: 59
  },
  icon12: {
    color: "rgba(197,24,100,1)",
    fontSize: 58
  },
  materialFixedLabelTextbox7: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 15,
    marginTop: 7
  },
  icon14: {
    color: "rgba(67,194,51,1)",
    fontSize: 58,
    marginLeft: 6
  },
  materialFixedLabelTextbox8: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 5,
    marginTop: 7
  },
  materialFixedLabelTextbox9: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 12,
    marginTop: 7
  },
  icon12Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 11,
    marginLeft: 63,
    marginRight: 14
  },
  icon17: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(11,107,108,1)",
    fontSize: 58
  },
  materialFixedLabelTextbox13: {
    top: 4,
    left: 56,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  icon17Stack: {
    width: 104,
    height: 58
  },
  icon19: {
    color: "rgba(21,205,78,1)",
    fontSize: 58,
    marginLeft: 3
  },
  materialFixedLabelTextbox10: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 1,
    marginTop: 4
  },
  icon21: {
    color: "rgba(176,82,82,1)",
    fontSize: 58,
    marginLeft: 6
  },
  icon17StackRow: {
    height: 58,
    flexDirection: "row",
    marginTop: 24,
    marginLeft: 24,
    marginRight: 73
  },
  icon22: {
    top: 0,
    left: 15,
    position: "absolute",
    color: "rgba(246,137,6,1)",
    fontSize: 58
  },
  image: {
    top: 32,
    left: 0,
    width: 222,
    height: 200,
    position: "absolute"
  },
  icon22Stack: {
    top: 0,
    left: 0,
    width: 222,
    height: 232,
    position: "absolute"
  },
  icon23: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(67,184,174,1)",
    fontSize: 58
  },
  icon27: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(67,184,174,1)",
    fontSize: 58
  },
  icon23Stack: {
    top: 0,
    left: 73,
    width: 58,
    height: 58,
    position: "absolute"
  },
  icon26: {
    top: 0,
    left: 45,
    position: "absolute",
    color: "rgba(209,19,19,1)",
    fontSize: 58
  },
  materialFixedLabelTextbox15: {
    top: 7,
    left: 0,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  icon26Stack: {
    top: 0,
    left: 194,
    width: 103,
    height: 58,
    position: "absolute"
  },
  materialFixedLabelTextbox14: {
    top: 7,
    left: 132,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  icon22StackStack: {
    width: 297,
    height: 232,
    marginTop: 23,
    marginLeft: 73
  },
  completaElAlfabeto: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: -596,
    marginLeft: 50
  }
});

export default P5;
