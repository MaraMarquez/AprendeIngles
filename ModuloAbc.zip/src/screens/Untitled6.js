import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Untitled6(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <MaterialButtonViolet
        style={styles.materialButtonViolet}
      ></MaterialButtonViolet>
      <View style={styles.rectStack}>
        <View style={styles.rect}>
          <Text style={styles.guay}>[guay]</Text>
        </View>
        <Image
          source={require("../assets/images/Letter-Y-PNG-Image.png")}
          resizeMode="contain"
          style={styles.image}
        ></Image>
      </View>
      <View style={styles.rect2}>
        <View style={styles.image2Stack}>
          <Image
            source={require("../assets/images/unnamed_(1).png")}
            resizeMode="contain"
            style={styles.image2}
          ></Image>
          <Text style={styles.zi}>[zi]</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 374,
    height: 62,
    marginTop: 30,
    marginLeft: 1
  },
  materialButtonViolet: {
    width: 158,
    height: 52,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 638,
    marginLeft: 109
  },
  rect: {
    top: 0,
    left: 20,
    width: 291,
    height: 242,
    backgroundColor: "rgba(201,213,255,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  guay: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 101,
    marginLeft: 166
  },
  image: {
    top: 32,
    left: 0,
    width: 209,
    height: 179,
    position: "absolute"
  },
  rectStack: {
    width: 311,
    height: 242,
    marginTop: -618,
    marginLeft: 27
  },
  rect2: {
    width: 291,
    height: 229,
    backgroundColor: "rgba(238,188,251,1)",
    borderColor: "#000000",
    borderWidth: 5,
    marginTop: 43,
    marginLeft: 47
  },
  image2: {
    top: 0,
    left: 0,
    width: 200,
    height: 200,
    position: "absolute"
  },
  zi: {
    top: 60,
    left: 193,
    color: "#121212",
    position: "absolute",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700"
  },
  image2Stack: {
    width: 249,
    height: 200,
    marginTop: 15
  }
});

export default Untitled6;
