import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialFixedLabelTextbox5 from "../components/MaterialFixedLabelTextbox5";
import MaterialFixedLabelTextbox6 from "../components/MaterialFixedLabelTextbox6";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import MaterialFixedLabelTextbox7 from "../components/MaterialFixedLabelTextbox7";

function Untitled1(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <View style={styles.selectVowelsStack}>
        <Text style={styles.selectVowels}></Text>
        <Text style={styles.matchTheLetters}>MATCH THE LETTERS</Text>
      </View>
      <View style={styles.materialFixedLabelTextbox5Stack}>
        <MaterialFixedLabelTextbox5
          style={styles.materialFixedLabelTextbox5}
        ></MaterialFixedLabelTextbox5>
        <MaterialFixedLabelTextbox6
          style={styles.materialFixedLabelTextbox6}
        ></MaterialFixedLabelTextbox6>
      </View>
      <View style={styles.rectStackStackRow}>
        <View style={styles.rectStackStack}>
          <View style={styles.rectStack}>
            <View style={styles.rect}></View>
            <MaterialCommunityIconsIcon
              name="alpha-b"
              style={styles.icon}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-a"
              style={styles.icon2}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-r"
              style={styles.icon3}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-q"
              style={styles.icon4}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-e"
              style={styles.icon5}
            ></MaterialCommunityIconsIcon>
            <MaterialFixedLabelTextbox7
              style={styles.materialFixedLabelTextbox7}
            ></MaterialFixedLabelTextbox7>
            <MaterialFixedLabelTextbox7
              style={styles.materialFixedLabelTextbox9}
            ></MaterialFixedLabelTextbox7>
            <MaterialFixedLabelTextbox7
              style={styles.materialFixedLabelTextbox10}
            ></MaterialFixedLabelTextbox7>
            <MaterialFixedLabelTextbox7
              style={styles.materialFixedLabelTextbox11}
            ></MaterialFixedLabelTextbox7>
          </View>
          <View style={styles.rect1}></View>
          <View style={styles.rect2}></View>
          <View style={styles.rect3}></View>
          <View style={styles.rect4}></View>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox8}
          ></MaterialFixedLabelTextbox7>
        </View>
        <View style={styles.rect5StackStack}>
          <View style={styles.rect5Stack}>
            <View style={styles.rect5}></View>
            <MaterialCommunityIconsIcon
              name="alpha-h"
              style={styles.icon6}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-k"
              style={styles.icon7}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-m"
              style={styles.icon8}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-t"
              style={styles.icon9}
            ></MaterialCommunityIconsIcon>
            <MaterialCommunityIconsIcon
              name="alpha-n"
              style={styles.icon10}
            ></MaterialCommunityIconsIcon>
          </View>
          <View style={styles.rect6}></View>
          <View style={styles.rect7}></View>
          <View style={styles.rect8}></View>
          <View style={styles.rect9}></View>
        </View>
        <View style={styles.materialFixedLabelTextbox12Column}>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox12}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox13}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox14}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox15}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox16}
          ></MaterialFixedLabelTextbox7>
        </View>
      </View>
      <Text style={styles.combinaLasLetras}>COMBINA LAS LETRAS</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 32,
    alignSelf: "center"
  },
  selectVowels: {
    top: 41,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  matchTheLetters: {
    top: 0,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  selectVowelsStack: {
    width: 375,
    height: 90,
    marginTop: 25
  },
  materialFixedLabelTextbox5: {
    top: 0,
    left: 0,
    width: 375,
    height: 43,
    backgroundColor: "rgba(186,222,27,1)",
    position: "absolute"
  },
  materialFixedLabelTextbox6: {
    top: 0,
    left: 212,
    width: 375,
    height: 43,
    backgroundColor: "rgba(186,222,27,1)",
    position: "absolute"
  },
  materialFixedLabelTextbox5Stack: {
    width: 587,
    height: 43,
    marginTop: 535
  },
  rect: {
    top: 13,
    left: 16,
    width: 85,
    height: 83,
    backgroundColor: "rgba(36,143,223,1)",
    position: "absolute"
  },
  icon: {
    top: 0,
    left: 5,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon2: {
    top: 96,
    left: 0,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon3: {
    top: 193,
    left: 5,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon4: {
    top: 288,
    left: 5,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon5: {
    top: 387,
    left: 5,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  materialFixedLabelTextbox7: {
    top: 14,
    left: 112,
    width: 65,
    height: 82,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox9: {
    top: 206,
    left: 111,
    width: 65,
    height: 82,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox10: {
    top: 305,
    left: 111,
    width: 65,
    height: 82,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox11: {
    top: 399,
    left: 114,
    width: 65,
    height: 82,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  rectStack: {
    top: 0,
    left: 0,
    width: 179,
    height: 497,
    position: "absolute"
  },
  rect1: {
    top: 110,
    left: 16,
    width: 85,
    height: 83,
    backgroundColor: "rgba(126,79,179,1)",
    position: "absolute"
  },
  rect2: {
    top: 205,
    left: 16,
    width: 85,
    height: 83,
    backgroundColor: "rgba(36,143,223,1)",
    position: "absolute"
  },
  rect3: {
    top: 301,
    left: 16,
    width: 85,
    height: 83,
    backgroundColor: "rgba(126,79,179,1)",
    position: "absolute"
  },
  rect4: {
    top: 401,
    left: 16,
    width: 85,
    height: 83,
    backgroundColor: "rgba(36,143,223,1)",
    position: "absolute"
  },
  materialFixedLabelTextbox8: {
    top: 111,
    left: 114,
    width: 65,
    height: 82,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  rectStackStack: {
    width: 179,
    height: 497
  },
  rect5: {
    top: 15,
    left: 15,
    width: 85,
    height: 83,
    backgroundColor: "rgba(126,79,179,1)",
    position: "absolute"
  },
  icon6: {
    top: 0,
    left: 4,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon7: {
    top: 97,
    left: 3,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon8: {
    top: 194,
    left: 3,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon9: {
    top: 289,
    left: 3,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  icon10: {
    top: 387,
    left: 0,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 110
  },
  rect5Stack: {
    top: 0,
    left: 0,
    width: 114,
    height: 497,
    position: "absolute"
  },
  rect6: {
    top: 111,
    left: 15,
    width: 85,
    height: 83,
    backgroundColor: "rgba(36,143,223,1)",
    position: "absolute"
  },
  rect7: {
    top: 207,
    left: 15,
    width: 85,
    height: 83,
    backgroundColor: "rgba(126,79,179,1)",
    position: "absolute"
  },
  rect8: {
    top: 303,
    left: 15,
    width: 85,
    height: 83,
    backgroundColor: "rgba(36,143,223,1)",
    position: "absolute"
  },
  rect9: {
    top: 402,
    left: 15,
    width: 85,
    height: 83,
    backgroundColor: "rgba(126,79,179,1)",
    position: "absolute"
  },
  rect5StackStack: {
    width: 114,
    height: 497,
    marginLeft: 1
  },
  materialFixedLabelTextbox12: {
    width: 65,
    height: 82,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 1
  },
  materialFixedLabelTextbox13: {
    width: 65,
    height: 82,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginTop: 15,
    marginLeft: 3
  },
  materialFixedLabelTextbox14: {
    width: 65,
    height: 82,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginTop: 13
  },
  materialFixedLabelTextbox15: {
    width: 65,
    height: 82,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginTop: 17
  },
  materialFixedLabelTextbox16: {
    width: 65,
    height: 82,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginTop: 12,
    marginLeft: 3
  },
  materialFixedLabelTextbox12Column: {
    width: 68,
    marginTop: 16,
    marginBottom: 14
  },
  rectStackStackRow: {
    height: 497,
    flexDirection: "row",
    marginTop: -550,
    marginLeft: -8,
    marginRight: 21
  },
  combinaLasLetras: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: -522,
    marginLeft: 52
  }
});

export default Untitled1;
