import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import MaterialFixedLabelTextbox from "../components/MaterialFixedLabelTextbox";
import MaterialFixedLabelTextbox1 from "../components/MaterialFixedLabelTextbox1";
import MaterialFixedLabelTextbox2 from "../components/MaterialFixedLabelTextbox2";
import Icon from "react-native-vector-icons/Entypo";

function P2(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader11 style={styles.materialHeader11}></MaterialHeader11>
      <Text style={styles.loremIpsum1}>WRITE WORDS WITH A, B, C</Text>
      <MaterialFixedLabelTextbox
        style={styles.materialFixedLabelTextbox}
      ></MaterialFixedLabelTextbox>
      <MaterialFixedLabelTextbox1
        style={styles.materialFixedLabelTextbox1}
      ></MaterialFixedLabelTextbox1>
      <MaterialFixedLabelTextbox2
        style={styles.materialFixedLabelTextbox2}
      ></MaterialFixedLabelTextbox2>
      <Image
        source={require("../assets/images/abc.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <Text style={styles.selectVowels1}>ESCRIBE PALABRAS CON A, B, C</Text>
      <View style={styles.button1Stack}>
        <TouchableOpacity style={styles.button1}></TouchableOpacity>
        <Icon name="arrow-long-right" style={styles.icon1}></Icon>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader11: {
    width: 375,
    height: 56,
    marginTop: 54
  },
  loremIpsum1: {
    color: "#121212",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: 20
  },
  materialFixedLabelTextbox: {
    width: 375,
    height: 43,
    backgroundColor: "rgba(186,222,27,1)",
    marginTop: 75
  },
  materialFixedLabelTextbox1: {
    width: 375,
    height: 43,
    backgroundColor: "rgba(186,222,27,1)",
    marginTop: 36
  },
  materialFixedLabelTextbox2: {
    width: 375,
    height: 43,
    backgroundColor: "rgba(186,222,27,1)",
    marginTop: 39
  },
  image: {
    width: 171,
    height: 153,
    marginTop: 30,
    marginLeft: 99
  },
  selectVowels1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: -455
  },
  button1: {
    top: 25,
    left: 0,
    width: 142,
    height: 62,
    backgroundColor: "rgba(94,198,94,1)",
    position: "absolute",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(68,67,67,1)"
  },
  icon1: {
    top: 0,
    left: 15,
    position: "absolute",
    color: "rgba(7,7,7,1)",
    fontSize: 112
  },
  button1Stack: {
    width: 142,
    height: 112,
    marginTop: 439,
    marginLeft: 116
  }
});

export default P2;
