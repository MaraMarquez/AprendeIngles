import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import MaterialButtonWithVioletText from "../components/MaterialButtonWithVioletText";
import MaterialButtonWithVioletText2 from "../components/MaterialButtonWithVioletText2";
import MaterialButtonWithVioletText3 from "../components/MaterialButtonWithVioletText3";

function Untitled1(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader11 style={styles.materialHeader11}></MaterialHeader11>
      <View style={styles.rectStack}>
        <View style={styles.rect}>
          <View style={styles.loremIpsum1Stack}>
            <Text style={styles.loremIpsum1}></Text>
            <MaterialButtonWithVioletText
              style={styles.materialButtonWithVioletText}
            ></MaterialButtonWithVioletText>
          </View>
        </View>
        <MaterialButtonWithVioletText2
          style={styles.materialButtonWithVioletText2}
        ></MaterialButtonWithVioletText2>
        <MaterialButtonWithVioletText3
          style={styles.materialButtonWithVioletText3}
        ></MaterialButtonWithVioletText3>
      </View>
      <Image
        source={require("../assets/images/546eda421ac26de0129a258959265300.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(15,15, 15,0)"
  },
  materialHeader11: {
    width: 375,
    height: 56,
    backgroundColor: "rgba(59,133,169,1)",
    marginTop: 34
  },
  rect: {
    top: 0,
    left: 51,
    width: 391,
    height: 293,
    backgroundColor: "rgba(15,15, 15,0.27)",
    position: "absolute"
  },
  loremIpsum1: {
    top: 0,
    left: 15,
    color: "#121212",
    position: "absolute",
    flexDirection: "row",
    justifyContent: "space-between",
    fontSize: 20,
    fontFamily: "helvetica-regular"
  },
  materialButtonWithVioletText: {
    top: 0,
    left: 0,
    width: 187,
    height: 36,
    position: "absolute"
  },
  loremIpsum1Stack: {
    width: 322,
    height: 36,
    marginTop: 51,
    marginLeft: 23
  },
  materialButtonWithVioletText2: {
    top: 99,
    left: 0,
    width: 313,
    height: 36,
    position: "absolute"
  },
  materialButtonWithVioletText3: {
    top: 147,
    left: 23,
    width: 290,
    height: 36,
    position: "absolute"
  },
  rectStack: {
    width: 442,
    height: 293,
    marginTop: 107,
    marginLeft: -51
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 58,
    alignSelf: "center"
  }
});

export default Untitled1;
