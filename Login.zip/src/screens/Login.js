import React, { Component } from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import MaterialMessageTextbox from "../components/MaterialMessageTextbox";
import MaterialMessageTextbox1 from "../components/MaterialMessageTextbox1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Login(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader11
        text1="Bienvenido a Aprende Ingles!"
        style={styles.materialHeader11}
      ></MaterialHeader11>
      <Image
        source={require("../assets/images/login2.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <Text style={styles.iniciaSesion}>¡Inicia Sesión!</Text>
      <MaterialMessageTextbox
        text1="Usuario:"
        textInput1="Nombre de usuario"
        style={styles.materialMessageTextbox}
      ></MaterialMessageTextbox>
      <MaterialMessageTextbox1
        text1="Contraseña:"
        textInput1="********"
        style={styles.materialMessageTextbox1}
      ></MaterialMessageTextbox1>
      <MaterialButtonViolet
        text1="INICIAR SESIÓN"
        style={styles.materialButtonViolet}
      ></MaterialButtonViolet>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader11: {
    width: 375,
    height: 56,
    marginTop: 36
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 72,
    alignSelf: "center"
  },
  iniciaSesion: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: -237,
    marginLeft: 114
  },
  materialMessageTextbox: {
    width: 264,
    height: 85,
    marginTop: 234,
    marginLeft: 58
  },
  materialMessageTextbox1: {
    width: 264,
    height: 90,
    marginTop: 51,
    alignSelf: "center"
  },
  materialButtonViolet: {
    width: 144,
    height: 35,
    shadowOffset: {
      width: 5,
      height: 5
    },
    shadowColor: "rgba(34,43,131,1)",
    marginTop: 46,
    marginLeft: 123
  }
});

export default Login;
