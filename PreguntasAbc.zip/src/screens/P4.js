import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialFixedLabelTextbox7 from "../components/MaterialFixedLabelTextbox7";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";

function P4(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <View style={styles.selectVowelsStack}>
        <Text style={styles.selectVowels}></Text>
        <Text style={styles.writeYourName}>WRITE YOUR NAME</Text>
      </View>
      <View style={styles.materialFixedLabelTextbox1Row}>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox1}
        ></MaterialFixedLabelTextbox7>
        <View style={styles.materialFixedLabelTextbox2Stack}>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox2}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox3}
          ></MaterialFixedLabelTextbox7>
        </View>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox4}
        ></MaterialFixedLabelTextbox7>
        <View style={styles.materialFixedLabelTextbox5Stack}>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox5}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox6}
          ></MaterialFixedLabelTextbox7>
        </View>
        <View style={styles.materialFixedLabelTextbox7Stack}>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox7}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox8}
          ></MaterialFixedLabelTextbox7>
        </View>
      </View>
      <View style={styles.iconRow}>
        <MaterialCommunityIconsIcon
          name="alpha-a-box"
          style={styles.icon}
        ></MaterialCommunityIconsIcon>
        <View style={styles.icon2Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-b-box"
            style={styles.icon2}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-c-box"
            style={styles.icon3}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-d-box"
            style={styles.icon4}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-e-box"
            style={styles.icon5}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-f-box"
            style={styles.icon6}
          ></MaterialCommunityIconsIcon>
        </View>
      </View>
      <View style={styles.icon7Stack}>
        <MaterialCommunityIconsIcon
          name="alpha-g-box"
          style={styles.icon7}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-h-box"
          style={styles.icon8}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-i-box"
          style={styles.icon9}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-j-box"
          style={styles.icon10}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-k-box"
          style={styles.icon11}
        ></MaterialCommunityIconsIcon>
      </View>
      <View style={styles.icon12Row}>
        <MaterialCommunityIconsIcon
          name="alpha-l-box"
          style={styles.icon12}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-m-box"
          style={styles.icon13}
        ></MaterialCommunityIconsIcon>
        <View style={styles.icon14Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-n-box"
            style={styles.icon14}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-o-box"
            style={styles.icon15}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-p-box"
            style={styles.icon16}
          ></MaterialCommunityIconsIcon>
        </View>
      </View>
      <View style={styles.icon17StackRow}>
        <View style={styles.icon17Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-q-box"
            style={styles.icon17}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-r-box"
            style={styles.icon18}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-s-box"
            style={styles.icon19}
          ></MaterialCommunityIconsIcon>
        </View>
        <View style={styles.icon20Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-t-box"
            style={styles.icon20}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-u-box"
            style={styles.icon21}
          ></MaterialCommunityIconsIcon>
        </View>
      </View>
      <View style={styles.icon22Row}>
        <MaterialCommunityIconsIcon
          name="alpha-v-box"
          style={styles.icon22}
        ></MaterialCommunityIconsIcon>
        <View style={styles.icon23Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-w-box"
            style={styles.icon23}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-x-box"
            style={styles.icon24}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-w-box"
            style={styles.icon27}
          ></MaterialCommunityIconsIcon>
        </View>
        <View style={styles.icon25Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-y-box"
            style={styles.icon25}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-z-box"
            style={styles.icon26}
          ></MaterialCommunityIconsIcon>
        </View>
      </View>
      <Text style={styles.escribeTuNombre}>ESCRIBE TU NOMBRE</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 52
  },
  selectVowels: {
    top: 25,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  writeYourName: {
    top: 0,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  selectVowelsStack: {
    width: 375,
    height: 90,
    marginTop: 21
  },
  materialFixedLabelTextbox1: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox2: {
    top: 0,
    left: 0,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox3: {
    top: 0,
    left: 44,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox2Stack: {
    width: 92,
    height: 51
  },
  materialFixedLabelTextbox4: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 1
  },
  materialFixedLabelTextbox5: {
    top: 0,
    left: 0,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox6: {
    top: 0,
    left: 44,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox5Stack: {
    width: 92,
    height: 51
  },
  materialFixedLabelTextbox7: {
    top: 0,
    left: 0,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox8: {
    top: 0,
    left: 44,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox7Stack: {
    width: 92,
    height: 51,
    marginLeft: 1
  },
  materialFixedLabelTextbox1Row: {
    height: 51,
    flexDirection: "row",
    marginTop: 487,
    marginLeft: 1
  },
  icon: {
    color: "rgba(225,229,78,1)",
    fontSize: 58
  },
  icon2: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(250,87,87,1)",
    fontSize: 58
  },
  icon3: {
    top: 0,
    left: 54,
    position: "absolute",
    color: "rgba(147,23,23,1)",
    fontSize: 58
  },
  icon4: {
    top: 0,
    left: 108,
    position: "absolute",
    color: "rgba(242,168,94,1)",
    fontSize: 58
  },
  icon5: {
    top: 0,
    left: 156,
    position: "absolute",
    color: "rgba(150,205,109,1)",
    fontSize: 58
  },
  icon6: {
    top: 0,
    left: 210,
    position: "absolute",
    color: "rgba(106,197,139,1)",
    fontSize: 58
  },
  icon2Stack: {
    width: 268,
    height: 58
  },
  iconRow: {
    height: 58,
    flexDirection: "row",
    marginTop: -484,
    marginLeft: 41,
    marginRight: 8
  },
  icon7: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(104,178,182,1)",
    fontSize: 58
  },
  icon8: {
    top: 0,
    left: 56,
    position: "absolute",
    color: "rgba(74,68,131,1)",
    fontSize: 58
  },
  icon9: {
    top: 0,
    left: 112,
    position: "absolute",
    color: "rgba(165,107,215,1)",
    fontSize: 58
  },
  icon10: {
    top: 0,
    left: 165,
    position: "absolute",
    color: "rgba(206,108,231,1)",
    fontSize: 58
  },
  icon11: {
    top: 0,
    left: 214,
    position: "absolute",
    color: "rgba(231,67,168,1)",
    fontSize: 58
  },
  icon7Stack: {
    width: 272,
    height: 58,
    marginTop: 32,
    marginLeft: 22
  },
  icon12: {
    color: "rgba(197,24,100,1)",
    fontSize: 58
  },
  icon13: {
    color: "rgba(207,6,20,1)",
    fontSize: 58,
    marginLeft: 7
  },
  icon14: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(67,194,51,1)",
    fontSize: 58
  },
  icon15: {
    top: 0,
    left: 50,
    position: "absolute",
    color: "rgba(240,214,66,1)",
    fontSize: 58
  },
  icon16: {
    top: 0,
    left: 102,
    position: "absolute",
    color: "rgba(80,83,188,1)",
    fontSize: 58
  },
  icon14Stack: {
    width: 160,
    height: 58,
    marginLeft: 4
  },
  icon12Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 12,
    marginLeft: 88
  },
  icon17: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(11,107,108,1)",
    fontSize: 58
  },
  icon18: {
    top: 0,
    left: 54,
    position: "absolute",
    color: "rgba(170,92,127,1)",
    fontSize: 58
  },
  icon19: {
    top: 0,
    left: 107,
    position: "absolute",
    color: "rgba(21,205,78,1)",
    fontSize: 58
  },
  icon17Stack: {
    width: 165,
    height: 58
  },
  icon20: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(138,19,205,1)",
    fontSize: 58
  },
  icon21: {
    top: 0,
    left: 55,
    position: "absolute",
    color: "rgba(176,82,82,1)",
    fontSize: 58
  },
  icon20Stack: {
    width: 113,
    height: 58
  },
  icon17StackRow: {
    height: 58,
    flexDirection: "row",
    marginTop: 23,
    marginLeft: 24,
    marginRight: 73
  },
  icon22: {
    color: "rgba(246,137,6,1)",
    fontSize: 58
  },
  icon23: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(67,184,174,1)",
    fontSize: 58
  },
  icon24: {
    top: 0,
    left: 54,
    position: "absolute",
    color: "rgba(248,54,140,1)",
    fontSize: 58
  },
  icon27: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(67,184,174,1)",
    fontSize: 58
  },
  icon23Stack: {
    width: 112,
    height: 58
  },
  icon25: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(62,133,65,1)",
    fontSize: 58
  },
  icon26: {
    top: 0,
    left: 54,
    position: "absolute",
    color: "rgba(209,19,19,1)",
    fontSize: 58
  },
  icon25Stack: {
    width: 112,
    height: 58
  },
  icon22Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 23,
    marginLeft: 88,
    marginRight: 5
  },
  escribeTuNombre: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: -420,
    marginLeft: 51
  }
});

export default P4;
