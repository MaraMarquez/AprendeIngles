import React, { Component } from "react";
import {
  StyleSheet,
  View,
  TextInput,
  Text,
  Image,
  TouchableOpacity
} from "react-native";
import EvilIconsIcon from "react-native-vector-icons/EvilIcons";

function Registro(props) {
  return (
    <View style={styles.container}>
      <View style={styles.form1}>
        <View style={styles.nameColumn}>
          <View style={styles.name}>
            <EvilIconsIcon name="user" style={styles.icon5}></EvilIconsIcon>
            <TextInput
              placeholder="Nombre"
              placeholderTextColor="rgba(0,0,0,1)"
              secureTextEntry={false}
              style={styles.nameInput}
            ></TextInput>
          </View>
          <View style={styles.email}>
            <EvilIconsIcon name="envelope" style={styles.icon6}></EvilIconsIcon>
            <TextInput
              placeholder="Correo"
              placeholderTextColor="rgba(0,0,0,1)"
              secureTextEntry={false}
              style={styles.emailInput}
            ></TextInput>
          </View>
        </View>
        <View style={styles.nameColumnFiller}></View>
        <View style={styles.password}>
          <EvilIconsIcon name="lock" style={styles.icon7}></EvilIconsIcon>
          <TextInput
            placeholder="Contraseña"
            placeholderTextColor="rgba(0,0,0,1)"
            secureTextEntry={true}
            style={styles.passwordInput}
          ></TextInput>
        </View>
      </View>
      <View style={styles.text3Row}>
        <Text style={styles.text3}>Registrarte</Text>
        <Image
          source={require("../assets/images/ezgif.com-gif-maker_(2).gif")}
          resizeMode="contain"
          style={styles.image1}
        ></Image>
      </View>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.continuar}>Continuar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  form1: {
    height: 230,
    marginTop: 188,
    marginLeft: 41,
    marginRight: 41
  },
  name: {
    width: 278,
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row",
    alignSelf: "center"
  },
  icon5: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    width: 33,
    height: 33,
    marginLeft: 15,
    alignSelf: "center"
  },
  nameInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    fontSize: 14,
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
  email: {
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row",
    marginTop: 27
  },
  icon6: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    marginLeft: 15,
    alignSelf: "center"
  },
  emailInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
  nameColumn: {},
  nameColumnFiller: {
    flex: 1
  },
  password: {
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row"
  },
  icon7: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    marginLeft: 15,
    marginTop: 13
  },
  passwordInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
  text3: {
    color: "rgba(43,97,198,1)",
    fontSize: 28,
    fontFamily: "roboto-regular",
    marginTop: 14
  },
  image1: {
    width: 71,
    height: 56
  },
  text3Row: {
    height: 56,
    flexDirection: "row",
    marginTop: -311,
    marginLeft: 112,
    marginRight: 41
  },
  button: {
    width: 278,
    height: 48,
    backgroundColor: "rgba(43,97,198,1)",
    borderRadius: 100,
    shadowOffset: {
      width: 5,
      height: 5
    },
    shadowColor: "rgba(23,72,163,1)",
    shadowOpacity: 0.5,
    marginTop: 295,
    marginLeft: 41
  },
  continuar: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginLeft: 85
  }
});

export default Registro;
