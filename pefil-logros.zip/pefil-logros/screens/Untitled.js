import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialCardWithContentAndActionButtons from "../components/MaterialCardWithContentAndActionButtons";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1
        button1="Untitled"
        icon2Name="settings"
        text1="Perfil"
        style={styles.materialHeader1}
      ></MaterialHeader1>
      <MaterialCardWithContentAndActionButtons
        text1="Usuario"
        text2="Logros"
        text3="Aqui se muestran los logros que ha tenido el usuario"
        text4="LOGROS"
        style={styles.materialCardWithContentAndActionButtons}
      ></MaterialCardWithContentAndActionButtons>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  materialHeader1: {
    width: 360,
    height: 50
  },
  materialCardWithContentAndActionButtons: {
    width: 359,
    height: 435,
    marginLeft: 1
  }
});

export default Untitled;
