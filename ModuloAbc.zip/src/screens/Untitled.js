import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <MaterialButtonViolet
        style={styles.materialButtonViolet}
      ></MaterialButtonViolet>
      <View style={styles.rect1Stack}>
        <View style={styles.rect1}>
          <Text style={styles.bi}>[bi]</Text>
        </View>
        <Image
          source={require("../assets/images/letter-b-png-7.png")}
          resizeMode="contain"
          style={styles.image2}
        ></Image>
        <View style={styles.rect4}>
          <Text style={styles.ei}>[ei]</Text>
          <Image
            source={require("../assets/images/letter-a-png-4.png")}
            resizeMode="contain"
            style={styles.image3}
          ></Image>
        </View>
      </View>
      <View style={styles.rect2StackStack}>
        <View style={styles.rect2Stack}>
          <View style={styles.rect2}>
            <Text style={styles.ci}>[ci]</Text>
          </View>
          <Image
            source={require("../assets/images/letter-d-transparent-image-d-png-512_512.png")}
            resizeMode="contain"
            style={styles.image4}
          ></Image>
          <Image
            source={require("../assets/images/letter_c_PNG110.png")}
            resizeMode="contain"
            style={styles.image5}
          ></Image>
        </View>
        <View style={styles.rect3}>
          <Text style={styles.di}>[di]</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 374,
    height: 62,
    marginTop: 30,
    marginLeft: 1
  },
  materialButtonViolet: {
    width: 158,
    height: 52,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 638,
    marginLeft: 109
  },
  rect1: {
    top: 0,
    left: 188,
    width: 187,
    height: 263,
    backgroundColor: "rgba(237,182,182,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  bi: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 52
  },
  image2: {
    top: 78,
    left: 181,
    width: 200,
    height: 163,
    position: "absolute"
  },
  rect4: {
    top: 0,
    left: 0,
    width: 188,
    height: 263,
    backgroundColor: "rgba(169,201,218,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  ei: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 67
  },
  image3: {
    width: 169,
    height: 166,
    marginTop: 21,
    marginLeft: 12
  },
  rect1Stack: {
    width: 381,
    height: 263,
    marginTop: -617
  },
  rect2: {
    top: 0,
    left: 3,
    width: 188,
    height: 249,
    backgroundColor: "rgba(237,193,190,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  ci: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 28,
    marginLeft: 70
  },
  image4: {
    top: 68,
    left: 184,
    width: 200,
    height: 169,
    position: "absolute"
  },
  image5: {
    top: 79,
    left: 0,
    width: 200,
    height: 158,
    position: "absolute"
  },
  rect2Stack: {
    top: 0,
    left: 0,
    width: 384,
    height: 249,
    position: "absolute"
  },
  rect3: {
    top: 0,
    left: 191,
    width: 187,
    height: 249,
    backgroundColor: "rgba(187,195,235,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  di: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 28,
    marginLeft: 52
  },
  rect2StackStack: {
    width: 384,
    height: 249,
    marginTop: 18,
    marginLeft: -3
  }
});

export default Untitled;
