import * as React from 'react';

import {Text,View,StyleSheet} from 'react-native';
import Constants from 'expo-constants';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
 
import HomeScreen from './pages/HomeScreen';
import RegisterUser from './pages/RegisterUser';
import ViewAllUser from './pages/ViewAllUser';
import Login from './pages/Login';
 
const App = createStackNavigator({
  HomeScreen: {
    screen: HomeScreen,
    navigationOptions: {
      title: 'HomeScreen',
      headerStyle: { backgroundColor: '#f05555' },
      headerTintColor: '#ffffff',
    },
  },
  ViewAll: {
    screen: ViewAllUser,
    navigationOptions: {
      title: 'View All User',
      headerStyle: { backgroundColor: '#f05555' },
      headerTintColor: '#ffffff',
    },
  },
  Register: {
    screen: RegisterUser,
    navigationOptions: {
      title: 'Register User',
      headerStyle: { backgroundColor: '#f05555' },
      headerTintColor: '#ffffff',
    },
  },
      Login: {
    screen: Login,
    navigationOptions: {
      title: 'Ingresar',
      headerStyle: { backgroundColor: '#f05555' },
      headerTintColor: '#ffffff',
    },
      }, 
});
export default createAppContainer(App);