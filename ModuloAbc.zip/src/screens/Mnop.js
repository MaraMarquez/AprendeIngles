import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Mnop(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <MaterialButtonViolet
        style={styles.materialButtonViolet}
      ></MaterialButtonViolet>
      <View style={styles.rectStackStack}>
        <View style={styles.rectStack}>
          <View style={styles.rect}>
            <Text style={styles.em}>[em]</Text>
          </View>
          <Image
            source={require("../assets/images/letter_m_PNG121.png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <View style={styles.rect1}>
          <Text style={styles.en}>[en]</Text>
          <Image
            source={require("../assets/images/letter_n_PNG90.png")}
            resizeMode="contain"
            style={styles.image2}
          ></Image>
        </View>
        <View style={styles.rect2}>
          <Text style={styles.ou}>[ou]</Text>
          <Image
            source={require("../assets/images/letter_o_PNG113.png")}
            resizeMode="contain"
            style={styles.image3}
          ></Image>
        </View>
        <View style={styles.rect3}>
          <Text style={styles.pi}>[pi]</Text>
          <Image
            source={require("../assets/images/letter_p_PNG88.png")}
            resizeMode="contain"
            style={styles.image4}
          ></Image>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 374,
    height: 62,
    marginTop: 30,
    marginLeft: 1
  },
  materialButtonViolet: {
    width: 158,
    height: 52,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 638,
    marginLeft: 109
  },
  rect: {
    top: 0,
    left: 0,
    width: 188,
    height: 263,
    backgroundColor: "rgba(223,180,222,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  em: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 68
  },
  image: {
    top: 26,
    left: 1,
    width: 200,
    height: 303,
    position: "absolute"
  },
  rectStack: {
    top: 0,
    left: 0,
    width: 201,
    height: 329,
    position: "absolute"
  },
  rect1: {
    top: 0,
    left: 188,
    width: 187,
    height: 263,
    backgroundColor: "rgba(247,200,200,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  en: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 66
  },
  image2: {
    width: 181,
    height: 166,
    marginTop: 28,
    marginLeft: 3
  },
  rect2: {
    top: 281,
    left: 0,
    width: 188,
    height: 229,
    backgroundColor: "rgba(247,183,214,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  ou: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 13,
    marginLeft: 74
  },
  image3: {
    width: 160,
    height: 157,
    marginTop: 5,
    marginLeft: 14
  },
  rect3: {
    top: 281,
    left: 188,
    width: 187,
    height: 229,
    backgroundColor: "rgba(230,189,251,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  pi: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 8,
    marginLeft: 52
  },
  image4: {
    width: 171,
    height: 167,
    marginTop: 5,
    marginLeft: 16
  },
  rectStackStack: {
    width: 375,
    height: 510,
    marginTop: -617
  }
});

export default Mnop;
