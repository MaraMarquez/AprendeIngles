import React, { Component } from 'react';
import { StyleSheet, View, Text, Button,TextInput, Image } from 'react-native';

export default class Login extends Component {
  render() {
    return (
      <View style={styles.wrapper}>
      <View style={styles.header}>
          <Text style={{fontSize: 20, fontWeight: 'bold'}}>Bienvenido a Aprende Ingles!</Text>
      </View>
       <View style={styles.contenido}>
        <Image
          source={require('imagen/login2.png')}
          style={[styles.div, styles.imagen]}
        />

         <TextInput style={styles.entrada} placeholder='Ingresa el Usuario'
           placeholderTextColor='black'
           onChangeText={(text) => this.setState({ text })}
         />
         
         <TextInput style={styles.entrada} placeholder='********'
           placeholderTextColor='black'
           onChangeText={(text) => this.setState({ text })}
         />
 
         <View style={styles.buttonStyle}>
          <Button
            title="Iniciar Sesion"
            color="#e0452d"
          />
        </View>
       </View>
 
       <View style={styles.footer}>
         <Text style={styles.textoP}> Aprende Ingles </Text>
         <Text style={styles.texto}> Hermosillo, Son. 2020 </Text>
       </View>
     </View >
   );
 }
}
const styles = StyleSheet.create({
 header: {
   flex: .2,
   flexDirection: 'row',
   alignItems: 'center',
   justifyContent: 'center',
   backgroundColor: '#4287f5',
   fontSize: 19,
   marginTop: 10
 },
 wrapper: {
   flex: 1,
   flexDirection: 'column',
   justifyContent: 'center',
   alignContent: 'center',
 },
 contenido: {
   flex: 1,
   alignItems: 'center',
   fontSize: 16,
   justifyContent: 'center',
 },
 textoP: {
   fontSize: 18,
   marginBottom: 30,
   fontWeight: 'bold',
 },
 entrada: {
   padding: 5,
   width: 250,
   fontSize: 16,
   borderWidth: 1,
   borderColor: 'black',
   borderRadius: 6,
   color: 'black',
   marginBottom: 10,
   marginTop: 30,
 },
 footer: {
   flex: .2,
   flexDirection: 'column',
   justifyContent: 'center',
   backgroundColor: '#DAE3E0',
   alignItems: 'center',
 },
 texto: {
   fontSize: 16,
 },
 buttonStyle: {
    marginBottom: 10,
    backgroundColor: "red",
    marginTop: 15,
  },
  imagen: {
    width: 200,
    height: 200,
  },
});