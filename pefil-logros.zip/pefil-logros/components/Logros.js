import React, { Component } from "react";
import { StyleSheet, View, StatusBar } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialCardWithContentAndActionButtons from "../components/MaterialCardWithContentAndActionButtons";

function Logros(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1
        button1="Untitled"
        icon2Name="settings"
        text1="Perfil"
        style={styles.materialHeader1}
      ></MaterialHeader1>
      <MaterialCardWithContentAndActionButtons
        text1="Usuario"
        text2="Logros"
        text3="Aqui se muestran los logros que ha tenido el usuario"
        text4="LOGROS"
        style={styles.materialCardWithContentAndActionButtons}
      ></MaterialCardWithContentAndActionButtons>
      <StatusBar hidden={true}></StatusBar>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  materialHeader1: {
    width: 361,
    height: 55
  },
  materialCardWithContentAndActionButtons: {
    width: 366,
    height: 641,
    alignSelf: "flex-end",
    borderColor: "#000000",
    borderWidth: 0,
    borderStyle: "dashed"
  }
});

export default Logros;
