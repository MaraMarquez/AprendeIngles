import React, { Component } from 'react';
import { StyleSheet, View, Text, Button,TextInput, Image } from 'react-native';

export default class App extends Component {
  render() {
    return (
      <View style={styles.wrapper}>
      <View style={styles.header}>
          <Text style={{fontSize: 20, fontWeight: 'bold', color:'white'}}>Acerca de Aprende Ingles</Text>
      </View>
       <View style={styles.contenido}>
        <Image
          source={require('imagen/acercaDe.PNG')}
          style={[styles.div, styles.imagen]}
        />
 
         <Text style={styles.parrafo}> El proposito de la aplicacion es poder ofrecer una herramienta para que las personas que tienen una discapacidad de aprendizaje puedan aprender el idioma ingles </Text>

       </View>
 
       <View style={styles.footer}>
         <Text style={styles.textoP}> Aprende Ingles </Text>
         <Text style={styles.texto}> Hermosillo, Son. 2020 </Text>
       </View>
     </View >
   );
 }
}
const styles = StyleSheet.create({
 header: {
   flex: .2,
   flexDirection: 'row',
   alignItems: 'center',
   justifyContent: 'center',
   backgroundColor: '#4287f5',
   fontSize: 19,
   marginTop: 10
 },
 wrapper: {
   flex: 1,
   flexDirection: 'column',
   justifyContent: 'center',
   alignContent: 'center',
 },
 contenido: {
   flex: 1,
   alignItems: 'center',
   fontSize: 16,
   justifyContent: 'center',
 },
 textoP: {
   fontSize: 18,
   marginBottom: 30,
   fontWeight: 'bold',
 },
 footer: {
   flex: .2,
   flexDirection: 'column',
   justifyContent: 'center',
   backgroundColor: '#DAE3E0',
   alignItems: 'center',
 },
 texto: {
   fontSize: 16,
 },
  parrafo: {
   fontSize: 16,
   alignItems: 'center',
   justifyContent: 'center',
   width: 300,
   textAlign:'center',
   marginTop:15

 },
  imagen: {
    width: 300,
    height: 160,
  },
});
