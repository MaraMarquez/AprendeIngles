import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import Icon from "react-native-vector-icons/Entypo";

function Efgh(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <View style={styles.rectStackStack}>
        <View style={styles.rectStack}>
          <View style={styles.rect}>
            <Text style={styles.i5}>[i]</Text>
          </View>
          <Image
            source={require("../assets/images/letter_e_PNG44.png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
          <Image
            source={require("../assets/images/letter_f_PNG46.png")}
            resizeMode="contain"
            style={styles.image2}
          ></Image>
        </View>
        <View style={styles.rect1}>
          <Text style={styles.ef}>[ef]</Text>
        </View>
      </View>
      <View style={styles.rect2StackStack}>
        <View style={styles.rect2Stack}>
          <View style={styles.rect2}>
            <Text style={styles.yi}>[yi]</Text>
          </View>
          <Image
            source={require("../assets/images/letter_g_PNG55.png")}
            resizeMode="contain"
            style={styles.image3}
          ></Image>
          <Image
            source={require("../assets/images/letter_h_PNG63.png")}
            resizeMode="contain"
            style={styles.image4}
          ></Image>
        </View>
        <View style={styles.rect3}>
          <Text style={styles.eich}>[eich]</Text>
        </View>
      </View>
      <View style={styles.button1Stack}>
        <TouchableOpacity style={styles.button1}></TouchableOpacity>
        <Icon name="arrow-long-right" style={styles.icon1}></Icon>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 374,
    height: 62,
    marginTop: 30,
    marginLeft: 1
  },
  rect: {
    top: 0,
    left: 12,
    width: 188,
    height: 263,
    backgroundColor: "rgba(247,235,189,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  i5: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 68
  },
  image: {
    top: 80,
    left: 0,
    width: 200,
    height: 161,
    position: "absolute"
  },
  image2: {
    top: 80,
    left: 193,
    width: 200,
    height: 161,
    position: "absolute"
  },
  rectStack: {
    top: 0,
    left: 0,
    width: 393,
    height: 263,
    position: "absolute"
  },
  rect1: {
    top: 0,
    left: 200,
    width: 187,
    height: 263,
    backgroundColor: "rgba(234,197,255,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  ef: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 52
  },
  rectStackStack: {
    width: 393,
    height: 263,
    marginTop: 73,
    marginLeft: -12
  },
  rect2: {
    top: 0,
    left: 6,
    width: 188,
    height: 250,
    backgroundColor: "rgba(123,129,146,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  yi: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 15,
    marginLeft: 68
  },
  image3: {
    top: 67,
    left: 0,
    width: 200,
    height: 168,
    position: "absolute"
  },
  image4: {
    top: 67,
    left: 187,
    width: 200,
    height: 168,
    position: "absolute"
  },
  rect2Stack: {
    top: 0,
    left: 0,
    width: 387,
    height: 250,
    position: "absolute"
  },
  rect3: {
    top: 0,
    left: 194,
    width: 187,
    height: 250,
    backgroundColor: "rgba(239,178,178,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  eich: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 15,
    marginLeft: 52
  },
  rect2StackStack: {
    width: 387,
    height: 250,
    marginTop: 18,
    marginLeft: -6
  },
  button1: {
    top: 25,
    left: 0,
    width: 146,
    height: 56,
    backgroundColor: "rgba(94,198,94,1)",
    position: "absolute",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.41
  },
  icon1: {
    top: 0,
    left: 20,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 106
  },
  button1Stack: {
    width: 146,
    height: 106,
    marginTop: 1,
    marginLeft: 121
  }
});

export default Efgh;
