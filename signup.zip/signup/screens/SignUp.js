import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  StatusBar
} from "react-native";
import EvilIconsIcon from "react-native-vector-icons/EvilIcons";

function SignUp(props) {
  return (
    <View style={styles.root}>
      <View style={styles.background}>
        <View style={styles.createAccountStackColumn}>
          <View style={styles.createAccountStack}>
            <Text style={styles.createAccount}>Registrarme</Text>
            <Image
              source={require("../assets/images/ezgif.com-gif-maker_(2).gif")}
              resizeMode="contain"
              style={styles.image}
            ></Image>
          </View>
          <View style={styles.form}>
            <View style={styles.nameColumn}>
              <View style={styles.name}>
                <EvilIconsIcon name="user" style={styles.icon5}></EvilIconsIcon>
                <TextInput
                  placeholder="Nombre"
                  placeholderTextColor="rgba(88,88,88,1)"
                  secureTextEntry={false}
                  style={styles.nameInput}
                ></TextInput>
              </View>
              <View style={styles.email}>
                <EvilIconsIcon
                  name="envelope"
                  style={styles.icon6}
                ></EvilIconsIcon>
                <TextInput
                  placeholder="Email"
                  placeholderTextColor="rgba(88,88,88,1)"
                  secureTextEntry={false}
                  style={styles.emailInput}
                ></TextInput>
              </View>
            </View>
            <View style={styles.nameColumnFiller}></View>
            <View style={styles.password}>
              <EvilIconsIcon name="lock" style={styles.icon7}></EvilIconsIcon>
              <TextInput
                placeholder="Password"
                placeholderTextColor="rgba(88,88,88,1)"
                secureTextEntry={true}
                style={styles.passwordInput}
              ></TextInput>
            </View>
          </View>
        </View>
        <View style={styles.createAccountStackColumnFiller}></View>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Timeline")}
          style={styles.continue}
        >
          <Text style={styles.text2}>Continuar</Text>
        </TouchableOpacity>
      </View>
      <StatusBar
        barStyle="light-content"
        hidden={true}
        backgroundColor="rgba(248,238,238,0)"
      ></StatusBar>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  background: {
    flex: 1
  },
  createAccount: {
    top: 25,
    left: 0,
    width: 278,
    height: 32,
    color: "rgba(43,97,198,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "roboto-regular",
    textAlign: "center"
  },
  image: {
    top: 0,
    left: 210,
    width: 68,
    height: 60,
    position: "absolute"
  },
  createAccountStack: {
    width: 278,
    height: 60
  },
  form: {
    height: 230,
    marginTop: 3
  },
  name: {
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    shadowOffset: {
      width: 5,
      height: 5
    },
    shadowColor: "rgba(186,222,27,1)",
    flexDirection: "row"
  },
  icon5: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    width: 33,
    height: 33,
    marginLeft: 15,
    alignSelf: "center"
  },
  nameInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    fontSize: 14,
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
  email: {
    width: 278,
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    shadowOffset: {
      width: 5,
      height: 5
    },
    shadowColor: "rgba(186,222,27,1)",
    flexDirection: "row",
    marginTop: 26,
    alignSelf: "center"
  },
  icon6: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    marginLeft: 15,
    alignSelf: "center"
  },
  emailInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
  nameColumn: {},
  nameColumnFiller: {
    flex: 1
  },
  password: {
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    shadowOffset: {
      width: 5,
      height: 5
    },
    shadowColor: "rgba(186,222,27,1)",
    flexDirection: "row"
  },
  icon7: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    marginLeft: 15,
    marginTop: 13
  },
  passwordInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
  createAccountStackColumn: {
    marginTop: 125,
    marginLeft: 41,
    marginRight: 41
  },
  createAccountStackColumnFiller: {
    flex: 1
  },
  continue: {
    height: 55,
    backgroundColor: "rgba(43,97,198,1)",
    opacity: 1,
    borderRadius: 100,
    justifyContent: "center",
    marginBottom: 151,
    marginLeft: 41,
    marginRight: 41
  },
  text2: {
    width: 94,
    color: "rgba(255,255,255,1)",
    fontSize: 20,
    fontFamily: "roboto-regular",
    alignSelf: "center"
  }
});

export default SignUp;
