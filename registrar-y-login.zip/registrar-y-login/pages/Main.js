import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
  Button,
  TextInput,
  Image,
  TouchableOpacity,
} from 'react-native';
import EvilIconsIcon from 'react-native-vector-icons/EvilIcons';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase('AprendeIngles.db');


export default class Main extends React.Component {
 constructor(props) {
    super(props);
    db.transaction(function(txn) {
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='USUARIOS'",
        [],
      );
    });
  }

  render() {
    return (
      <View>
      <Text>Debe acceder aqui</Text>
      </View>
    );
  }
}
