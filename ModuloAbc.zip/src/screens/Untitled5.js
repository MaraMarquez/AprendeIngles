import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Untitled5(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <MaterialButtonViolet
        style={styles.materialButtonViolet}
      ></MaterialButtonViolet>
      <View style={styles.rectStackStack}>
        <View style={styles.rectStack}>
          <View style={styles.rect}>
            <Text style={styles.iu}>[iu]</Text>
          </View>
          <Image
            source={require("../assets/images/4ed835cf3c9ea7e150190dfc176a8f2a-membrete-de-ne--n-rojo-alfabeto-u-by-vexels.png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
          <Image
            source={require("../assets/images/7217d48d90b1b9d037b6769038b6ce20-membrete-rojo-ne--n-tipo-de-letra-v-by-vexels.png")}
            resizeMode="contain"
            style={styles.image2}
          ></Image>
        </View>
        <View style={styles.rect1}>
          <Text style={styles.vi}>[vi]</Text>
        </View>
        <View style={styles.rect2Stack}>
          <View style={styles.rect2}>
            <Text style={styles.doblIu}>[dobl{"\n"} iu]</Text>
          </View>
          <Image
            source={require("../assets/images/7c20e38bcbd5028cea5bdb4d566aa86e-membrete-de-ne--n-rojo-con-letra-w-by-vexels.png")}
            resizeMode="contain"
            style={styles.image3}
          ></Image>
          <Image
            source={require("../assets/images/2fb949c4cddcbe8216aff479680717e3-membrete-de-ne--n-rojo-alfabeto-x-by-vexels.png")}
            resizeMode="contain"
            style={styles.image4}
          ></Image>
        </View>
        <View style={styles.rect3}>
          <Text style={styles.ex}>[ex]</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 374,
    height: 62,
    marginTop: 30,
    marginLeft: 1
  },
  materialButtonViolet: {
    width: 158,
    height: 52,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 638,
    marginLeft: 109
  },
  rect: {
    top: 0,
    left: 6,
    width: 188,
    height: 263,
    backgroundColor: "rgba(249,178,251,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  iu: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 68
  },
  image: {
    top: 77,
    left: 0,
    width: 200,
    height: 208,
    position: "absolute"
  },
  image2: {
    top: 81,
    left: 194,
    width: 200,
    height: 200,
    position: "absolute"
  },
  rectStack: {
    top: 0,
    left: 0,
    width: 394,
    height: 285,
    position: "absolute"
  },
  rect1: {
    top: 0,
    left: 194,
    width: 187,
    height: 263,
    backgroundColor: "rgba(198,212,255,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  vi: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 66
  },
  rect2: {
    top: 0,
    left: 6,
    width: 188,
    height: 229,
    backgroundColor: "rgba(201,147,255,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  doblIu: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 4,
    marginLeft: 59
  },
  image3: {
    top: 60,
    left: 0,
    width: 200,
    height: 200,
    position: "absolute"
  },
  image4: {
    top: 60,
    left: 194,
    width: 200,
    height: 200,
    position: "absolute"
  },
  rect2Stack: {
    top: 281,
    left: 0,
    width: 394,
    height: 260,
    position: "absolute"
  },
  rect3: {
    top: 281,
    left: 194,
    width: 187,
    height: 229,
    backgroundColor: "rgba(243,162,162,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  ex: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 20,
    marginLeft: 65
  },
  rectStackStack: {
    width: 394,
    height: 541,
    marginTop: -617,
    marginLeft: -6
  }
});

export default Untitled5;
