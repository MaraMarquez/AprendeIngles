/*Custom Button*/
import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

const BotonContinuar = props => {
  return (
    <TouchableOpacity style={styles.button} onPress={props.customClick}>
      <Text style={styles.text}>{props.title}</Text>
    </TouchableOpacity>
  );
};
const styles = StyleSheet.create({
  button: {
    width: 278,
    height: 48,
    backgroundColor: "rgba(43,97,198,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(23,72,163,1)",
    shadowOpacity: 0.5,
    marginTop: 295,
    marginLeft: 41
  },
  text: {
     color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginLeft: 85
  },
});
export default BotonContinuar;