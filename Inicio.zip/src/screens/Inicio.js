import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonPrimary from "../components/MaterialButtonPrimary";

function Inicio(props) {
  return (
    <View style={styles.container}>
      <Text style={styles.bienvenido}>¡Bienvenido!</Text>
      <MaterialHeader1
        text1="Aprende Ingles!"
        style={styles.materialHeader1}
      ></MaterialHeader1>
      <Image
        source={require("../assets/images/logo.jpg")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <MaterialButtonPrimary
        text1="Comenzar"
        style={styles.materialButtonPrimary}
      ></MaterialButtonPrimary>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  bienvenido: {
    color: "#121212",
    fontSize: 28,
    fontFamily: "roboto-regular",
    textAlign: "center",
    marginTop: 151,
    marginLeft: 111
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: -141,
    marginLeft: -1
  },
  image: {
    width: 313,
    height: 355,
    marginTop: 85,
    marginLeft: 30
  },
  materialButtonPrimary: {
    width: 192,
    height: 55,
    marginTop: 17,
    marginLeft: 92
  }
});

export default Inicio;
