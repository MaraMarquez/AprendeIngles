import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <View style={styles.informacionStack}>
        <Text style={styles.informacion}></Text>
        <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      </View>
      <View style={styles.rect1}>
        <Text style={styles.loremIpsum}>
          Creemos que cualquiera puede aprender un inglés con APRENDIENDO
          INGLÉS. Nuestras lecciones cortas y gratuitas están diseñadas para
          sentirse más como un juego que como un libro de estudios. Aprender es
          más fácil cuando te diviertes.{"\n"}Pero no es solo un juego. Está
          basado en una metodología que fomenta la retención a largo plazo de
          los contenidos y un plan de estudios alineado con los estándares
          internacionales.
        </Text>
      </View>
      <Image
        source={require("../assets/images/INFO1.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  informacion: {
    top: 55,
    left: 40,
    color: "#121212",
    position: "absolute",
    fontFamily: "roboto-regular"
  },
  materialHeader1: {
    top: 0,
    left: 0,
    width: 375,
    height: 56,
    position: "absolute"
  },
  informacionStack: {
    width: 375,
    height: 56,
    marginTop: 34
  },
  rect1: {
    width: 375,
    height: 309,
    backgroundColor: "rgba(15,15, 15,0.27)",
    marginTop: 111,
    alignSelf: "center"
  },
  loremIpsum: {
    color: "#121212",
    fontSize: 20,
    fontFamily: "roboto-regular",
    marginTop: 31,
    marginLeft: 12
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 38,
    alignSelf: "center"
  }
});

export default Untitled;
