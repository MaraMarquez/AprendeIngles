import React, { Component } from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import MaterialHeader12 from "../components/MaterialHeader12";

function AcercaDe(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader12
        text1="Acerca de Aprende Ingles"
        style={styles.materialHeader12}
      ></MaterialHeader12>
      <Image
        source={require("../assets/images/acercaDe.PNG")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <Text style={styles.loremIpsum}>
        El propósito de la aplicación es poder ofrecer una herramienta para que
        las personas que tienen una discapacidad de aprendizaje puedan aprender
        el idioma Inglés.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader12: {
    width: 375,
    height: 56,
    marginTop: 36
  },
  image: {
    width: 339,
    height: 181,
    marginTop: 133,
    alignSelf: "center"
  },
  loremIpsum: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    textAlign: "center",
    marginTop: 11,
    marginLeft: 9
  }
});

export default AcercaDe;
