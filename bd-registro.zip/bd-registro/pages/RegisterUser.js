/*Screen to register the user*/
import* as React from 'react';
import { View, ScrollView, KeyboardAvoidingView, Alert, TextInput,Image,TouchableOpacity, Text,StyleSheet } from 'react-native';
import * as SQLite from 'expo-sqlite';
import EvilIconsIcon from 'react-native-vector-icons/EvilIcons';

const db = SQLite.openDatabase('AprendeIngles.db');
import Mytextinput from './components/Mytextinput';
import Mybutton from './components/Mybutton';
import BotonC from './components/BotonContinuar';

import { openDatabase } from 'react-native-sqlite-storage';

//var db = openDatabase({ name: 'UserDatabase.db' });
export default class RegisterUser extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nombre: '',
      correo: '',
      contrasena: '',
    };
  }
 
  register_user = () => {
    var that = this;
    const { nombre } = this.state;
    const { correo } = this.state;
    const { contrasena } = this.state;
    //alert(user_name, user_contact, user_address);
    if (nombre) {
      if (correo) {
        if (contrasena) {
          db.transaction(function(tx) {
            tx.executeSql(
              'INSERT INTO USUARIOS (nombre, correo, contrasena) VALUES (?,?,?)',
              [nombre, correo, contrasena],
              (tx, results) => {
                console.log('Results', results.rowsAffected);
                if (results.rowsAffected > 0) {
                  Alert.alert(
                    'Success',
                    'Registro exitoso',
                    [
                      {
                        text: 'Ok',
                        onPress: () =>
                          that.props.navigation.navigate('HomeScreen'),
                      },
                    ],
                    { cancelable: false }
                  );
                } else {
                  alert('Registro Fallido');
                }
              }
            );
          });
        } else {
          alert('Por favor de ingresar su contraseña');
        }
      } else {
        alert('Por favor de ingresar su correo');
      }
    } else {
      alert('Por favor de ingresar su nombre');
    }
  };

  render() {
    return (
      <View style={{ backgroundColor: 'rgba(243,255,200,1)', flex: 1 }}>
      <ScrollView keyboardShouldPersistTaps="handled">
      <KeyboardAvoidingView
        behavior="padding"
        style={{ flex: 1, justifyContent: 'space-between' }}>

      <View style={styles.form1}>

        <View style={styles.nameColumn}>
          <View style={styles.name}>
            <EvilIconsIcon name="user" style={styles.icon5}></EvilIconsIcon>
            <Mytextinput
              placeholder="Nombre"
              keyboardType="email-address"
              onChangeText={nombre => this.setState({ nombre })}
            />
          </View>

          <View style={styles.email}>
            <EvilIconsIcon name="envelope" style={styles.icon6}></EvilIconsIcon>
            <Mytextinput
              placeholder="Correo"
              keyboardType="email-address"
              onChangeText={correo => this.setState({ correo })}
            />
          </View>
        </View>
        <View style={styles.nameColumnFiller}></View>
        <View style={styles.password}>
          <EvilIconsIcon name="lock" style={styles.icon7}></EvilIconsIcon>
          <Mytextinput
            placeholder="Contraseña"
              onChangeText={contrasena => this.setState({ contrasena })}
          />
        </View>
      </View>
      <View style={styles.text3Row}>
        <Text style={styles.text3}>Registrate</Text>
        <Image
          source={require("../assets/image/ezgif.com-gif-maker_(2).gif")}
          resizeMode="contain"
          style={styles.image1}
        ></Image>
      </View>
      <BotonC 
        title = 'Continuar'
        customClick ={this.register_user.bind(this)} />

    </KeyboardAvoidingView>
  </ScrollView>

    </View>
    );
  }
}
const styles = StyleSheet.create({
  form1: {
    width: 278,
    height: 230,
    marginTop: 106,
     alignSelf: "center"
  },
  name: {
    width: 278,
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row",
    alignSelf: "center"
  },
  icon5: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    width: 33,
    height: 33,
    marginLeft: 15,
    alignSelf: "center"
  },
 
  email: {
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row",
    marginTop: 27
  },
  icon6: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    marginLeft: 15,
    alignSelf: "center"
  },

  nameColumn: {},
  nameColumnFiller: {
    flex: 1
  },
  password: {
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row"
  },
  icon7: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    marginLeft: 15,
    marginTop: 13
  },

  text3: {
    color: "rgba(43,97,198,1)",
    fontSize: 28,
    fontFamily: "roboto-regular",
    marginTop: 14
  },
  image1: {
    width: 71,
    height: 56
  },
  text3Row: {
    height: 56,
    flexDirection: "row",
    marginTop: -336,
    marginLeft: 112,
    marginRight: 41
  },
});