import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Untitled4(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <MaterialButtonViolet
        style={styles.materialButtonViolet}
      ></MaterialButtonViolet>
      <View style={styles.rectStackRow}>
        <View style={styles.rectStack}>
          <View style={styles.rect}>
            <Text style={styles.kiu}>[kiu]</Text>
          </View>
          <Image
            source={require("../assets/images/letter_q_PNG40.png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <View style={styles.rect1}>
          <Text style={styles.ar}>[ar]</Text>
          <Image
            source={require("../assets/images/5a01c8c2cad612fd15711852.png")}
            resizeMode="contain"
            style={styles.image2}
          ></Image>
        </View>
      </View>
      <View style={styles.rect2StackStack}>
        <View style={styles.rect2Stack}>
          <View style={styles.rect2}>
            <Text style={styles.es}>[es]</Text>
          </View>
          <Image
            source={require("../assets/images/5a01c8f0cad612fd15711854.png")}
            resizeMode="contain"
            style={styles.image3}
          ></Image>
          <Image
            source={require("../assets/images/unnamed.png")}
            resizeMode="contain"
            style={styles.image4}
          ></Image>
        </View>
        <View style={styles.rect3}>
          <Text style={styles.ti}>[ti]</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 374,
    height: 62,
    marginTop: 30,
    marginLeft: 1
  },
  materialButtonViolet: {
    width: 158,
    height: 52,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 638,
    marginLeft: 109
  },
  rect: {
    top: 0,
    left: 0,
    width: 188,
    height: 263,
    backgroundColor: "rgba(246,249,162,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  kiu: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 68
  },
  image: {
    top: 89,
    left: 15,
    width: 158,
    height: 175,
    position: "absolute"
  },
  rectStack: {
    width: 188,
    height: 264
  },
  rect1: {
    width: 187,
    height: 263,
    backgroundColor: "rgba(213,237,180,1)",
    borderColor: "#000000",
    borderWidth: 5
  },
  ar: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 52
  },
  image2: {
    width: 160,
    height: 149,
    marginTop: 50,
    marginLeft: 13
  },
  rectStackRow: {
    height: 264,
    flexDirection: "row",
    marginTop: -617
  },
  rect2: {
    top: 0,
    left: 0,
    width: 188,
    height: 229,
    backgroundColor: "rgba(186,194,249,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  es: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 7,
    marginLeft: 73
  },
  image3: {
    top: 65,
    left: 181,
    width: 200,
    height: 165,
    position: "absolute"
  },
  image4: {
    top: 47,
    left: 0,
    width: 200,
    height: 200,
    position: "absolute"
  },
  rect2Stack: {
    top: 0,
    left: 0,
    width: 381,
    height: 247,
    position: "absolute"
  },
  rect3: {
    top: 0,
    left: 188,
    width: 187,
    height: 229,
    backgroundColor: "rgba(243,207,190,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  ti: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 7,
    marginLeft: 66
  },
  rect2StackStack: {
    width: 381,
    height: 247,
    marginTop: 17
  }
});

export default Untitled4;
