import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  Image,
  ImageBackground,
  TouchableOpacity
} from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import Icon from "react-native-vector-icons/Entypo";

function Ijkl(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <View style={styles.rectStackStack}>
        <View style={styles.rectStack}>
          <View style={styles.rect}>
            <Text style={styles.ai2}>[ai]</Text>
          </View>
          <Image
            source={require("../assets/images/letter_i_PNG74.png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
          <Image
            source={require("../assets/images/letter_j_PNG71.png")}
            resizeMode="contain"
            style={styles.image2}
          ></Image>
        </View>
        <View style={styles.rect1}>
          <Text style={styles.yei}>[yei]</Text>
        </View>
      </View>
      <View style={styles.rect2StackStack}>
        <View style={styles.rect2Stack}>
          <View style={styles.rect2}></View>
          <ImageBackground
            source={require("../assets/images/letter_k_PNG18.png")}
            resizeMode="contain"
            style={styles.image3}
            imageStyle={styles.image3_imageStyle}
          >
            <Text style={styles.kei}>[kei]</Text>
          </ImageBackground>
          <Image
            source={require("../assets/images/letter_L_PNG6.png")}
            resizeMode="contain"
            style={styles.image4}
          ></Image>
          <TouchableOpacity style={styles.button1}></TouchableOpacity>
          <Icon name="arrow-long-right" style={styles.icon1}></Icon>
        </View>
        <View style={styles.rect3}>
          <Text style={styles.el}>[el]</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 374,
    height: 62,
    marginTop: 30,
    marginLeft: 1
  },
  rect: {
    top: 0,
    left: 6,
    width: 188,
    height: 263,
    backgroundColor: "rgba(255,214,236,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  ai2: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 68
  },
  image: {
    top: 64,
    left: 0,
    width: 200,
    height: 200,
    position: "absolute"
  },
  image2: {
    top: 64,
    left: 187,
    width: 200,
    height: 200,
    position: "absolute"
  },
  rectStack: {
    top: 0,
    left: 0,
    width: 387,
    height: 264,
    position: "absolute"
  },
  rect1: {
    top: 0,
    left: 194,
    width: 187,
    height: 263,
    backgroundColor: "rgba(191,223,185,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  yei: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 14,
    marginLeft: 66
  },
  rectStackStack: {
    width: 387,
    height: 264,
    marginTop: 73,
    marginLeft: -6
  },
  rect2: {
    top: 0,
    left: 23,
    width: 188,
    height: 247,
    backgroundColor: "rgba(212,188,237,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  image3: {
    top: 13,
    left: 0,
    width: 256,
    height: 336,
    position: "absolute"
  },
  image3_imageStyle: {},
  kei: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginLeft: 91
  },
  image4: {
    top: 36,
    left: 164,
    width: 281,
    height: 234,
    position: "absolute"
  },
  button1: {
    top: 276,
    left: 144,
    width: 146,
    height: 56,
    backgroundColor: "rgba(94,198,94,1)",
    position: "absolute",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.41
  },
  icon1: {
    top: 251,
    left: 164,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 106
  },
  rect2Stack: {
    top: 0,
    left: 0,
    width: 445,
    height: 357,
    position: "absolute"
  },
  rect3: {
    top: 0,
    left: 211,
    width: 187,
    height: 247,
    backgroundColor: "rgba(176,213,231,1)",
    position: "absolute",
    borderColor: "#000000",
    borderWidth: 5
  },
  el: {
    color: "#121212",
    fontSize: 40,
    fontFamily: "baloo-bhai-2-700",
    marginTop: 13,
    marginLeft: 66
  },
  rect2StackStack: {
    width: 445,
    height: 357,
    marginTop: 17,
    marginLeft: -23
  }
});

export default Ijkl;
