import * as React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Button,
  TextInput,
  Image,
  TouchableOpacity,
  Alert,
  ScrollView,
  KeyboardAvoidingView
} from 'react-native';
import EvilIconsIcon from 'react-native-vector-icons/EvilIcons';
import * as SQLite from 'expo-sqlite';

import Mytextinput from './components/Mytextinput';
import BotonC from './components/BotonContinuar';

import { openDatabase } from 'react-native-sqlite-storage';

const db = SQLite.openDatabase('AprendeIngles.db');

export default class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nombre: '',
      contrasena: '',
    };
  }
/*
    componentWillUnmount() {
        this.closeDatabase();
    }

    openSuccess() {
        console.log("Database is opened");
    }

    openError(err) {
        console.log("error: ", err);
    }

    closeDatabase = () => {
        if (db) {
            console.log("Closing database ...");
            db.close();
        } else {
            console.log("Database was not OPENED");
        }
    }
*/
 onLogin() {
        var that = this;
        const { nombre, contrasena } = this.state;
        if (nombre === '' || contrasena === '') {
            alert('Please enter your username and password!');
            return;
        }
        db.transaction((tx) => {
            const sql = `SELECT * FROM USUARIOS WHERE nombre='${nombre}'`;
            tx.executeSql(sql, [], (tx, results) => {
                const len = results.rows.length;
                if (!len) {
                    alert('This account does not exist!');
                } else {
                    const row = results.rows.item(0);
                    if (contrasena === row.contrasena) {
                      Alert.alert(
                        'Success',
                        'Bienvenido',
                        [
                          {
                            text: 'Ok',
                            onPress: () =>
                            that.props.navigation.navigate('ViewAll')
                          }
                        ],
                         { cancelable: false }
                      );
                   //     console.log("Ya entro aqui WOWOWOWO");
                    //    this.props.navigation.navigate('ViewAll');
                     //   alert("Bienvenido :D");
                        return;
                    }
                    if(nombre ===  row.nombre){
                      console.log("Ha entrado al ciclo: "+results.rows.item(0));

                    }
                    alert('Authentication failed!');
                }
            });
        });
    }
   render() {
    return (
   <View style={{ backgroundColor: 'rgba(243,255,200,1)', flex: 1 }}>
      <ScrollView keyboardShouldPersistTaps="handled">
      <KeyboardAvoidingView
        behavior="padding"
        style={{ flex: 1, justifyContent: 'space-between' }}>

      <View style={styles.form1}>

        <View style={styles.nameColumn}>
          <View style={styles.name}>
            <EvilIconsIcon name="user" style={styles.icon5}></EvilIconsIcon>
            <Mytextinput
              placeholder="Nombre"
              keyboardType="email-address"
              onChangeText={nombre => this.setState({ nombre })}
            />
          </View>

          <View style={styles.email}>
            <EvilIconsIcon name="lock" style={styles.icon6}></EvilIconsIcon>
            <Mytextinput
              placeholder="Contraseña"
              onChangeText={contrasena => this.setState({ contrasena })}
            />
          </View>
        </View>
      </View>
      <View style={styles.text3Row}>
        <Text style={styles.text3}>Iniciar sesión</Text>
        <Image
          source={require("../assets/image/login2.png")}
          resizeMode="contain"
          style={styles.image1}
        ></Image>
      </View>
      <BotonC 
        title = 'Continuar'
        customClick ={this.onLogin.bind(this)} />

    </KeyboardAvoidingView>
  </ScrollView>
    </View>
    );
  }
}
const styles = StyleSheet.create({
 form1: {
    width: 278,
    height: 230,
    marginTop: 106,
     alignSelf: "center"
  },
  name: {
    width: 278,
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row",
    alignSelf: "center"
  },
  icon5: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    width: 33,
    height: 33,
    marginLeft: 15,
    alignSelf: "center"
  },
 
  email: {
    height: 59,
    backgroundColor: "rgba(255,255,255,0.25)",
    opacity: 1,
    borderRadius: 100,
    borderColor: "rgba(126,211,33,1)",
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(126,211,33,1)",
    shadowOpacity: 0.5,
    flexDirection: "row",
    marginTop: 27
  },
  icon6: {
    color: "rgba(43,97,198,1)",
    fontSize: 33,
    marginLeft: 15,
    alignSelf: "center"
  },
  text3: {
    color: "rgba(43,97,198,1)",
    fontSize: 28,
    fontFamily: "roboto-regular",
    marginTop: 14
  },
  image1: {
    width: 71,
    height: 56
  },
  text3Row: {
    height: 56,
    flexDirection: "row",
    marginTop: -336,
    marginLeft: 100,
    marginRight: 41
  },
});