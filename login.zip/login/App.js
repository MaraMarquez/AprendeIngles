import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
  Button,
  TextInput,
  Image,
  TouchableOpacity,
} from 'react-native';
import EvilIconsIcon from 'react-native-vector-icons/EvilIcons';

export default class App extends Component {
  render() {
    return (
      <View style={styles.wrapper}>
        <View style={styles.contenido}>
          <Image
            source={require('imagen/login2.png')}
            style={[styles.div, styles.imagen]}
          />
          <View>
            <View style={styles.usuario}>
              <EvilIconsIcon name="user" style={styles.icon5} />
              <TextInput
                placeholder="Ingrese el usuario o email"
                placeholderTextColor="rgba(0,0,0,1)"
                secureTextEntry={false}
                style={styles.usuarioInput}
              />
            </View>
            <View style={styles.password}>
              <EvilIconsIcon name="envelope" style={styles.icon6} />
              <TextInput
                placeholder="*******"
                placeholderTextColor="rgba(0,0,0,1)"
                secureTextEntry={false}
                style={styles.passInput}
              />
            </View>
          </View>

          <TouchableOpacity style={styles.button}>
            <Text style={styles.text}>Siguiente</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignContent: 'center',
    backgroundColor: '#F3FFC8',
  },
  contenido: {
    flex: 1,
    alignItems: 'center',
    fontSize: 16,
    justifyContent: 'center',
  },
  imagen: {
    width: 200,
    height: 200,
  },
  button: {
    borderRadius: 10,
    width: 100,
    height: 35,
    backgroundColor: '#7E4FB3',
    shadowOffset: {
      width: 5,
      height: 5,
    },
    shadowColor: '#222B83',
    elevation: 6,
    alignSelf: 'center',
    marginTop: 60,
  },
  text: {
    color: 'white',
    textAlign: 'center',
    fontFamily: 'Roboto, sans-serif',
    fontSize: 20,
    marginTop: 3,
  },
  icon5: {
    color: 'rgba(43,97,198,1)',
    fontSize: 33,
    width: 33,
    height: 33,
    marginLeft: 15,
    alignSelf: 'center',
  },
  usuario: {
    marginTop: 25,
    width: 278,
    height: 59,
    backgroundColor: 'rgba(255,255,255,0.25)',
    opacity: 1,
    borderRadius: 100,
    borderColor: 'rgba(126,211,33,1)',
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5,
    },
    shadowColor: 'rgba(126,211,33,1)',
    shadowOpacity: 0.5,
    flexDirection: 'row',
    alignSelf: 'center',
  },
  password: {
    height: 59,
    backgroundColor: 'rgba(255,255,255,0.25)',
    opacity: 1,
    borderRadius: 100,
    borderColor: 'rgba(126,211,33,1)',
    borderWidth: 1,
    shadowOffset: {
      height: 5,
      width: 5,
    },
    shadowColor: 'rgba(126,211,33,1)',
    shadowOpacity: 0.5,
    flexDirection: 'row',
    marginTop: 27,
  },
  icon6: {
    color: 'rgba(43,97,198,1)',
    fontSize: 33,
    marginLeft: 15,
    alignSelf: 'center',
  },  
   usuarioInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    fontSize: 14,
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
  passInput: {
    height: 30,
    color: "rgba(0,0,0,1)",
    fontSize: 14,
    flex: 1,
    marginRight: 17,
    marginLeft: 13,
    marginTop: 14
  },
});
