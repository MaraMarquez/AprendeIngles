import React, { Component } from "react";
import { StyleSheet, View, Image } from "react-native";
import MaterialHeader12 from "../components/MaterialHeader12";
import IoniconsIcon from "react-native-vector-icons/Ionicons";
import MaterialHelperTextBox from "../components/MaterialHelperTextBox";

function Untitled2(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader12 style={styles.materialHeader12}></MaterialHeader12>
      <View style={styles.iconRow}>
        <IoniconsIcon name="ios-star" style={styles.icon}></IoniconsIcon>
        <IoniconsIcon name="ios-star" style={styles.icon1}></IoniconsIcon>
        <IoniconsIcon name="ios-star" style={styles.icon2}></IoniconsIcon>
        <IoniconsIcon name="ios-star" style={styles.icon3}></IoniconsIcon>
        <IoniconsIcon name="ios-star" style={styles.icon4}></IoniconsIcon>
      </View>
      <MaterialHelperTextBox
        style={styles.materialHelperTextBox}
      ></MaterialHelperTextBox>
      <View style={styles.imageRow}>
        <Image
          source={require("../assets/images/INFO.png")}
          resizeMode="contain"
          style={styles.image}
        ></Image>
        <Image
          source={require("../assets/images/535-5351252_animales-bebes-animados-png-transparent-png.png")}
          resizeMode="contain"
          style={styles.image2}
        ></Image>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  materialHeader12: {
    width: 375,
    height: 56,
    marginTop: 34
  },
  icon: {
    color: "rgba(221,195,40,1)",
    fontSize: 40
  },
  icon1: {
    color: "rgba(221,195,40,1)",
    fontSize: 40,
    marginLeft: 23
  },
  icon2: {
    color: "rgba(221,195,40,1)",
    fontSize: 40,
    marginLeft: 21
  },
  icon3: {
    color: "rgba(221,195,40,1)",
    fontSize: 40,
    marginLeft: 22
  },
  icon4: {
    color: "rgba(221,195,40,1)",
    fontSize: 40,
    marginLeft: 17
  },
  iconRow: {
    height: 40,
    flexDirection: "row",
    marginTop: 129,
    marginLeft: 56,
    marginRight: 61
  },
  materialHelperTextBox: {
    width: 333,
    height: 138,
    marginTop: 48,
    marginLeft: 18
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 61
  },
  image2: {
    width: 366,
    height: 299,
    marginLeft: 555
  },
  imageRow: {
    height: 299,
    flexDirection: "row",
    marginTop: 20,
    marginLeft: -754,
    marginRight: 8
  }
});

export default Untitled2;
