import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialCheckboxWithLabel from "../components/MaterialCheckboxWithLabel";
import MaterialCheckboxWithLabel3 from "../components/MaterialCheckboxWithLabel3";
import MaterialCheckboxWithLabel7 from "../components/MaterialCheckboxWithLabel7";
import MaterialCheckboxWithLabel1 from "../components/MaterialCheckboxWithLabel1";
import MaterialCheckboxWithLabel6 from "../components/MaterialCheckboxWithLabel6";
import MaterialCheckboxWithLabel4 from "../components/MaterialCheckboxWithLabel4";
import MaterialCheckboxWithLabel2 from "../components/MaterialCheckboxWithLabel2";
import MaterialCheckboxWithLabel5 from "../components/MaterialCheckboxWithLabel5";
import MaterialCheckboxWithLabel8 from "../components/MaterialCheckboxWithLabel8";

function P1(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <Text style={styles.selectVowels}>SELECT VOWELS</Text>
      <View style={styles.materialCheckboxWithLabelRow}>
        <MaterialCheckboxWithLabel
          style={styles.materialCheckboxWithLabel}
        ></MaterialCheckboxWithLabel>
        <MaterialCheckboxWithLabel3
          style={styles.materialCheckboxWithLabel3}
        ></MaterialCheckboxWithLabel3>
        <MaterialCheckboxWithLabel7
          style={styles.materialCheckboxWithLabel7}
        ></MaterialCheckboxWithLabel7>
      </View>
      <View style={styles.materialCheckboxWithLabel1Row}>
        <MaterialCheckboxWithLabel1
          style={styles.materialCheckboxWithLabel1}
        ></MaterialCheckboxWithLabel1>
        <MaterialCheckboxWithLabel6
          style={styles.materialCheckboxWithLabel6}
        ></MaterialCheckboxWithLabel6>
        <MaterialCheckboxWithLabel4
          style={styles.materialCheckboxWithLabel4}
        ></MaterialCheckboxWithLabel4>
      </View>
      <View style={styles.materialCheckboxWithLabel2Row}>
        <MaterialCheckboxWithLabel2
          style={styles.materialCheckboxWithLabel2}
        ></MaterialCheckboxWithLabel2>
        <MaterialCheckboxWithLabel5
          style={styles.materialCheckboxWithLabel5}
        ></MaterialCheckboxWithLabel5>
        <MaterialCheckboxWithLabel8
          style={styles.materialCheckboxWithLabel8}
        ></MaterialCheckboxWithLabel8>
      </View>
      <Image
        source={require("../assets/images/1f9e6fec5a5a434f556c5a7ac895844d-icono-de-pizarra-de-abc-by-vexels.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <Text style={styles.selectVowels1}>SELECCIONA LAS VOCALES</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 52
  },
  selectVowels: {
    color: "#121212",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: 48,
    alignSelf: "center"
  },
  materialCheckboxWithLabel: {
    width: 100,
    height: 85
  },
  materialCheckboxWithLabel3: {
    width: 90,
    height: 40,
    marginLeft: 18,
    marginTop: 23
  },
  materialCheckboxWithLabel7: {
    width: 90,
    height: 40,
    marginLeft: 52,
    marginTop: 28
  },
  materialCheckboxWithLabelRow: {
    height: 85,
    flexDirection: "row",
    marginTop: 50,
    marginLeft: -2,
    marginRight: 27
  },
  materialCheckboxWithLabel1: {
    width: 90,
    height: 40
  },
  materialCheckboxWithLabel6: {
    width: 90,
    height: 40,
    marginLeft: 23
  },
  materialCheckboxWithLabel4: {
    width: 90,
    height: 40,
    marginLeft: 52
  },
  materialCheckboxWithLabel1Row: {
    height: 40,
    flexDirection: "row",
    marginTop: 1,
    marginLeft: 3,
    marginRight: 27
  },
  materialCheckboxWithLabel2: {
    width: 90,
    height: 40
  },
  materialCheckboxWithLabel5: {
    width: 90,
    height: 40,
    marginLeft: 23
  },
  materialCheckboxWithLabel8: {
    width: 90,
    height: 40,
    marginLeft: 52
  },
  materialCheckboxWithLabel2Row: {
    height: 40,
    flexDirection: "row",
    marginTop: 26,
    marginLeft: 3,
    marginRight: 27
  },
  image: {
    width: 299,
    height: 245,
    marginTop: 65,
    alignSelf: "center"
  },
  selectVowels1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: -540,
    alignSelf: "center"
  }
});

export default P1;
