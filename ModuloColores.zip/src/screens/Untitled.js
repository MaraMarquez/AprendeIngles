import React, { Component } from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1
        text1="Módulo 1: Colores"
        style={styles.materialHeader1}
      ></MaterialHeader1>
      <Image
        source={require("../assets/images/black.PNG")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <Text style={styles.black}>BLACK</Text>
      <MaterialButtonViolet
        text1="Siguente"
        style={styles.materialButtonViolet}
      ></MaterialButtonViolet>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 46
  },
  image: {
    width: 288,
    height: 277,
    marginTop: 106,
    alignSelf: "center"
  },
  black: {
    color: "#121212",
    fontSize: 50,
    fontFamily: "roboto-700",
    marginTop: 24,
    alignSelf: "center"
  },
  materialButtonViolet: {
    width: 142,
    height: 49,
    marginTop: 91,
    alignSelf: "center"
  }
});

export default Untitled;
