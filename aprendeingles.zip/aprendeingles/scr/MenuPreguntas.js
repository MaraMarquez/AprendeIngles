import React, { Component } from 'react';
import { StyleSheet, View, Text, Button,TextInput, Image } from 'react-native';

export default class MenuPreguntas extends Component {
  render() {
    return (
      <View style={styles.wrapper}>
      <View style={styles.header}>
          <Text style={{fontSize: 20, fontWeight: 'bold', color:'white'}}>Menú de Preguntas</Text>
      </View>
       <View style={styles.contenido}>
        <View style={styles.buttonStyle}>
          <Button
            title="Preguntas de Colores"
            color="#ffc629"
          />
        </View>
         <View style={styles.buttonStyle}>
          <Button
            title="Preguntas de Verduras"
            color="#51d663"
          />
        </View>
         <View style={styles.buttonStyle}>
          <Button
            title="Preguntas del Abecedario"
            color="#ad589c"
          />
        </View>
          <View style={styles.buttonStyle}>
          <Button
            title="Preguntas de los Números"
            color="#ff7417"
          />
        </View>

       </View>
 
       <View style={styles.footer}>
         <Text style={styles.textoP}> Aprende Ingles </Text>
         <Text style={styles.texto}> Hermosillo, Son. 2020 </Text>
       </View>
     </View >
   );
 }
}
const styles = StyleSheet.create({
 header: {
   flex: .2,
   flexDirection: 'row',
   alignItems: 'center',
   justifyContent: 'center',
   backgroundColor: '#4287f5',
   fontSize: 19,
   marginTop: 10
 },
 wrapper: {
   flex: 1,
   flexDirection: 'column',
   justifyContent: 'center',
   alignContent: 'center',
 },
 contenido: {
   flex: 1,
   alignItems: 'center',
   fontSize: 16,
   justifyContent: 'center',
 },
 textoP: {
   fontSize: 18,
   marginBottom: 30,
   fontWeight: 'bold',
 },
 footer: {
   flex: .2,
   flexDirection: 'column',
   justifyContent: 'center',
   backgroundColor: '#DAE3E0',
   alignItems: 'center',
 },
 texto: {
   fontSize: 16,
 },
 buttonStyle: {
    height: 40,
    width:330,
  },
});