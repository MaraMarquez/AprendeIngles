import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialFixedLabelTextbox7 from "../components/MaterialFixedLabelTextbox7";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";

function P4(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <View style={styles.selectVowelsStack}>
        <Text style={styles.selectVowels}></Text>
        <Text style={styles.writeYourName}>WRITE YOUR NAME</Text>
      </View>
      <View style={styles.materialFixedLabelTextbox1Row}>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox1}
        ></MaterialFixedLabelTextbox7>
        <View style={styles.materialFixedLabelTextbox2Stack}>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox2}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox3}
          ></MaterialFixedLabelTextbox7>
        </View>
        <MaterialFixedLabelTextbox7
          style={styles.materialFixedLabelTextbox4}
        ></MaterialFixedLabelTextbox7>
        <View style={styles.materialFixedLabelTextbox5Stack}>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox5}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox6}
          ></MaterialFixedLabelTextbox7>
        </View>
        <View style={styles.materialFixedLabelTextbox7Stack}>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox7}
          ></MaterialFixedLabelTextbox7>
          <MaterialFixedLabelTextbox7
            style={styles.materialFixedLabelTextbox8}
          ></MaterialFixedLabelTextbox7>
        </View>
      </View>
      <View style={styles.iconRow}>
        <MaterialCommunityIconsIcon
          name="alpha-a-box"
          style={styles.icon}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-b-box"
          style={styles.icon2}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-c-box"
          style={styles.icon3}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-d-box"
          style={styles.icon4}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-e-box"
          style={styles.icon5}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-f-box"
          style={styles.icon6}
        ></MaterialCommunityIconsIcon>
      </View>
      <View style={styles.icon7Row}>
        <MaterialCommunityIconsIcon
          name="alpha-g-box"
          style={styles.icon7}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-h-box"
          style={styles.icon8}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-i-box"
          style={styles.icon9}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-j-box"
          style={styles.icon10}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-k-box"
          style={styles.icon11}
        ></MaterialCommunityIconsIcon>
      </View>
      <View style={styles.icon12Row}>
        <MaterialCommunityIconsIcon
          name="alpha-l-box"
          style={styles.icon12}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-m-box"
          style={styles.icon13}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-n-box"
          style={styles.icon14}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-o-box"
          style={styles.icon15}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-p-box"
          style={styles.icon16}
        ></MaterialCommunityIconsIcon>
      </View>
      <View style={styles.icon17Row}>
        <MaterialCommunityIconsIcon
          name="alpha-q-box"
          style={styles.icon17}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-r-box"
          style={styles.icon18}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-s-box"
          style={styles.icon19}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-t-box"
          style={styles.icon20}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-u-box"
          style={styles.icon21}
        ></MaterialCommunityIconsIcon>
      </View>
      <View style={styles.icon22Row}>
        <MaterialCommunityIconsIcon
          name="alpha-v-box"
          style={styles.icon22}
        ></MaterialCommunityIconsIcon>
        <View style={styles.icon23Stack}>
          <MaterialCommunityIconsIcon
            name="alpha-w-box"
            style={styles.icon23}
          ></MaterialCommunityIconsIcon>
          <MaterialCommunityIconsIcon
            name="alpha-w-box"
            style={styles.icon27}
          ></MaterialCommunityIconsIcon>
        </View>
        <MaterialCommunityIconsIcon
          name="alpha-x-box"
          style={styles.icon24}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-y-box"
          style={styles.icon25}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="alpha-z-box"
          style={styles.icon26}
        ></MaterialCommunityIconsIcon>
      </View>
      <Text style={styles.escribeTuNombre}>ESCRIBE TU NOMBRE</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 52
  },
  selectVowels: {
    top: 25,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  writeYourName: {
    top: 0,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 45,
    fontFamily: "roboto-700",
    textAlign: "center"
  },
  selectVowelsStack: {
    width: 375,
    height: 90,
    marginTop: 21
  },
  materialFixedLabelTextbox1: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox2: {
    top: 0,
    left: 0,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox3: {
    top: 0,
    left: 44,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox2Stack: {
    width: 92,
    height: 51
  },
  materialFixedLabelTextbox4: {
    width: 48,
    height: 51,
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5,
    marginLeft: 1
  },
  materialFixedLabelTextbox5: {
    top: 0,
    left: 0,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox6: {
    top: 0,
    left: 44,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox5Stack: {
    width: 92,
    height: 51
  },
  materialFixedLabelTextbox7: {
    top: 0,
    left: 0,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox8: {
    top: 0,
    left: 44,
    width: 48,
    height: 51,
    position: "absolute",
    transform: [
      {
        rotate: "179.00deg"
      }
    ],
    borderColor: "#000000",
    borderWidth: 5
  },
  materialFixedLabelTextbox7Stack: {
    width: 92,
    height: 51,
    marginLeft: 1
  },
  materialFixedLabelTextbox1Row: {
    height: 51,
    flexDirection: "row",
    marginTop: 487,
    marginLeft: 1
  },
  icon: {
    color: "rgba(225,229,78,1)",
    fontSize: 58
  },
  icon2: {
    color: "rgba(250,87,87,1)",
    fontSize: 58,
    marginLeft: 14
  },
  icon3: {
    color: "rgba(147,23,23,1)",
    fontSize: 58,
    marginLeft: 10
  },
  icon4: {
    color: "rgba(242,168,94,1)",
    fontSize: 58,
    marginLeft: 10
  },
  icon5: {
    color: "rgba(150,205,109,1)",
    fontSize: 58,
    marginLeft: 4
  },
  icon6: {
    color: "rgba(106,197,139,1)",
    fontSize: 58,
    marginLeft: 10
  },
  iconRow: {
    height: 58,
    flexDirection: "row",
    marginTop: -484,
    marginLeft: 41,
    marginRight: 22
  },
  icon7: {
    color: "rgba(104,178,182,1)",
    fontSize: 58
  },
  icon8: {
    color: "rgba(74,68,131,1)",
    fontSize: 58,
    marginLeft: 12
  },
  icon9: {
    color: "rgba(165,107,215,1)",
    fontSize: 58,
    marginLeft: 12
  },
  icon10: {
    color: "rgba(206,108,231,1)",
    fontSize: 58,
    marginLeft: 9
  },
  icon11: {
    color: "rgba(231,67,168,1)",
    fontSize: 58,
    marginLeft: 5
  },
  icon7Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 32,
    marginLeft: 22,
    marginRight: 95
  },
  icon12: {
    color: "rgba(197,24,100,1)",
    fontSize: 58
  },
  icon13: {
    color: "rgba(207,6,20,1)",
    fontSize: 58,
    marginLeft: 21
  },
  icon14: {
    color: "rgba(67,194,51,1)",
    fontSize: 58,
    marginLeft: 18
  },
  icon15: {
    color: "rgba(240,214,66,1)",
    fontSize: 58,
    marginLeft: 6
  },
  icon16: {
    color: "rgba(80,83,188,1)",
    fontSize: 58,
    marginLeft: 8
  },
  icon12Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 12,
    marginLeft: 88,
    marginRight: 14
  },
  icon17: {
    color: "rgba(11,107,108,1)",
    fontSize: 58
  },
  icon18: {
    color: "rgba(170,92,127,1)",
    fontSize: 58,
    marginLeft: 10
  },
  icon19: {
    color: "rgba(21,205,78,1)",
    fontSize: 58,
    marginLeft: 9
  },
  icon20: {
    color: "rgba(138,19,205,1)",
    fontSize: 58,
    marginLeft: 14
  },
  icon21: {
    color: "rgba(176,82,82,1)",
    fontSize: 58,
    marginLeft: 19
  },
  icon17Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 23,
    marginLeft: 24,
    marginRight: 99
  },
  icon22: {
    color: "rgba(246,137,6,1)",
    fontSize: 58
  },
  icon23: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(67,184,174,1)",
    fontSize: 58
  },
  icon27: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(67,184,174,1)",
    fontSize: 58
  },
  icon23Stack: {
    width: 52,
    height: 58,
    marginLeft: 26
  },
  icon24: {
    color: "rgba(248,54,140,1)",
    fontSize: 58,
    marginLeft: 2
  },
  icon25: {
    color: "rgba(62,133,65,1)",
    fontSize: 58,
    marginLeft: 6
  },
  icon26: {
    color: "rgba(209,19,19,1)",
    fontSize: 58,
    marginLeft: 18
  },
  icon22Row: {
    height: 58,
    flexDirection: "row",
    marginTop: 23,
    marginLeft: 88,
    marginRight: 23
  },
  escribeTuNombre: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-700",
    textAlign: "center",
    marginTop: -420,
    marginLeft: 51
  }
});

export default P4;
