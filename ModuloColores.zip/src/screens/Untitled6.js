import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Untitled6(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1
        text1="Módulo 1: Colores"
        style={styles.materialHeader1}
      ></MaterialHeader1>
      <Text style={styles.red}>RED</Text>
      <MaterialButtonViolet
        text1="Siguente"
        style={styles.materialButtonViolet1}
      ></MaterialButtonViolet>
      <Image
        source={require("../assets/images/red.PNG")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 48,
    alignSelf: "center"
  },
  red: {
    color: "rgba(183,24,40,1)",
    fontSize: 50,
    fontFamily: "roboto-700",
    marginTop: 415,
    alignSelf: "center"
  },
  materialButtonViolet1: {
    width: 142,
    height: 49,
    marginTop: 73,
    alignSelf: "center"
  },
  image: {
    width: 375,
    height: 303,
    marginTop: -519
  }
});

export default Untitled6;
