import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function Untitled7(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1
        text1="Módulo 1: Colores"
        style={styles.materialHeader1}
      ></MaterialHeader1>
      <MaterialButtonViolet
        text1="Siguente"
        style={styles.materialButtonViolet1}
      ></MaterialButtonViolet>
      <Text style={styles.white}>WHITE</Text>
      <Image
        source={require("../assets/images/white.PNG")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 375,
    height: 56,
    marginTop: 48,
    alignSelf: "center"
  },
  materialButtonViolet1: {
    width: 142,
    height: 49,
    marginTop: 538,
    alignSelf: "center"
  },
  white: {
    color: "rgba(0,0,0,1)",
    fontSize: 50,
    fontFamily: "roboto-700",
    marginTop: -174,
    marginLeft: 112
  },
  image: {
    width: 378,
    height: 282,
    marginTop: -385
  }
});

export default Untitled7;
