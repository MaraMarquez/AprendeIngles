/*Screen to view single user*/
import* as React from 'react';
import { Text, View, Button, TextInput } from 'react-native';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase('AprendeIngles.db');
import Mytextinput from './components/Mytextinput';
import Mybutton from './components/Mybutton';
import { openDatabase } from 'react-native-sqlite-storage';
//var db = openDatabase({ name: 'UserDatabase.db' }); 
export default class ViewUser extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      input_nombre: '',
      userData: '',
    };
  }
  searchUser = () => {
    const { input_nombre } = this.state;
    console.log(this.state.input_nombre);
    db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM USUARIOS where nombre = ?',
        [input_nombre],
        (tx, results) => {
          var len = results.rows.length;
          console.log('len', len);
          if (len > 0) {
            this.setState({
              userData: results.rows.item(0),
            });
          } else {
            alert('No user found');
            this.setState({
              userData: '',
            });
          }
        }
      );
    });
  };
  render() {
    return (
      <View>
        <Mytextinput
          placeholder="Ingrese el nombre"
          onChangeText={input_nombre => this.setState({ input_nombre })}
          style={{ padding:10 }}
        />
        <Mybutton
          title="Buscar"
          customClick={this.searchUser.bind(this)}
        />
        <View style={{ marginLeft: 35, marginRight: 35, marginTop: 10 }}>
          <Text>User Id: {this.state.userData.id}</Text>
          <Text>User nombre: {this.state.userData.nombre}</Text>
          <Text>User correo: {this.state.userData.correo}</Text>
          <Text>User contrasena: {this.state.userData.contrasena}</Text>
        </View>
      </View>
    );
  }
}