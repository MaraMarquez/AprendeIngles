import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialCardWithContentAndActionButtons from "../components/MaterialCardWithContentAndActionButtons";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <MaterialHeader1 style={styles.materialHeader1}></MaterialHeader1>
      <MaterialCardWithContentAndActionButtons
        style={styles.materialCardWithContentAndActionButtons}
      ></MaterialCardWithContentAndActionButtons>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  materialHeader1: {
    width: 360,
    height: 56
  },
  materialCardWithContentAndActionButtons: {
    width: 359,
    height: 435
  }
});

export default Untitled;
