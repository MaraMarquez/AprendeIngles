import React, { useState } from "react";
import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { createDrawerNavigator } from "react-navigation-drawer";
import { AppLoading } from "expo";
import * as Font from "expo-font";
import Untitled1 from "./src/screens/Untitled1";
import Untitled2 from "./src/screens/Untitled2";
import Untitled from "./src/screens/Untitled";
import Untitled3 from "./src/screens/Untitled3";
import Untitled4 from "./src/screens/Untitled4";
import Untitled5 from "./src/screens/Untitled5";
import Untitled6 from "./src/screens/Untitled6";
import Abcd from "./src/screens/Abcd";
import Efgh from "./src/screens/Efgh";
import Ijkl from "./src/screens/Ijkl";
import Mnop from "./src/screens/Mnop";
import Qrst from "./src/screens/Qrst";
import Uvwx from "./src/screens/Uvwx";
import Yz from "./src/screens/Yz";

const DrawerNavigation = createDrawerNavigator({
  Untitled1: Untitled1,
  Untitled2: Untitled2,
  Untitled: Untitled,
  Untitled3: Untitled3,
  Untitled4: Untitled4,
  Untitled5: Untitled5,
  Untitled6: Untitled6,
  Abcd: Abcd,
  Efgh: Efgh,
  Ijkl: Ijkl,
  Mnop: Mnop,
  Qrst: Qrst,
  Uvwx: Uvwx,
  Yz: Yz
});

const StackNavigation = createStackNavigator(
  {
    DrawerNavigation: {
      screen: DrawerNavigation
    },
    Untitled1: Untitled1,
    Untitled2: Untitled2,
    Untitled: Untitled,
    Untitled3: Untitled3,
    Untitled4: Untitled4,
    Untitled5: Untitled5,
    Untitled6: Untitled6,
    Abcd: Abcd,
    Efgh: Efgh,
    Ijkl: Ijkl,
    Mnop: Mnop,
    Qrst: Qrst,
    Uvwx: Uvwx,
    Yz: Yz
  },
  {
    headerMode: "none"
  }
);

const AppContainer = createAppContainer(StackNavigation);

function App() {
  const [isLoadingComplete, setLoadingComplete] = useState(false);
  if (!isLoadingComplete) {
    return (
      <AppLoading
        startAsync={loadResourcesAsync}
        onError={handleLoadingError}
        onFinish={() => handleFinishLoading(setLoadingComplete)}
      />
    );
  } else {
    return isLoadingComplete ? <AppContainer /> : <AppLoading />;
  }
}
async function loadResourcesAsync() {
  await Promise.all([
    Font.loadAsync({
      "roboto-regular": require("./src/assets/fonts/roboto-regular.ttf"),
      "baloo-bhai-2-700": require("./src/assets/fonts/baloo-bhai-2-700.ttf"),
      "helvetica-regular": require("./src/assets/fonts/helvetica-regular.ttf")
    })
  ]);
}
function handleLoadingError(error) {
  console.warn(error);
}

function handleFinishLoading(setLoadingComplete) {
  setLoadingComplete(true);
}

export default App;
